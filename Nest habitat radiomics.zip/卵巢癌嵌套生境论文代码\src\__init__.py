"""嵌套生境超声影像组学预测卵巢癌 3 年复发 —— 代码包。

模块划分与稿件 Methods 对应关系：
    io_utils            数据读取（NRRD 分割、超声图像、临床表）与队列划分
    preprocess          去噪 / 分辨率归一 / 重采样 / ROI 内归一化
    habitat             5×5 滑窗局部特征 + 两轮 K-means（CH 指标）嵌套生境分割
    radiomics_extraction PyRadiomics 特征提取（含 LoG、wavelet）
    icc                 观察者内 / 观察者间 ICC 稳定性筛选
    feature_selection   标准化 → 组间检验 → 相关性/mRMR 去冗余 → LASSO
    models              9 种机器学习算法与 5 折网格搜索
    combined            临床-生境联合模型（逻辑回归）与列线图
    metrics             AUC / 校准 / Hosmer-Lemeshow / DCA / DeLong / NRI / IDI
    plotting            ROC、校准曲线、DCA、热图、重要性图等
    shap_explain        SHAP 解释
    immune_analysis     影像标签与免疫微环境标志物的相关性分析
"""

__version__ = "1.0.0"
__all__ = [
    "io_utils",
    "preprocess",
    "habitat",
    "radiomics_extraction",
    "icc",
    "feature_selection",
    "models",
    "combined",
    "metrics",
    "plotting",
    "shap_explain",
    "immune_analysis",
]
