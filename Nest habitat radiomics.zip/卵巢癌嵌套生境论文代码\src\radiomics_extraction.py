"""影像组学特征提取（双后端）。

后端 backend:
    pyradiomics : 稿件使用的官方实现（shape2D/firstorder/GLCM/GLRLM/GLSZM/
                  GLDM/NGTDM + LoG + Wavelet），特征数约 1000+（本代码包按
                  稿件记录的 1561 设定期望值，实际数量由参数文件决定）
    lite        : 内置纯 numpy 实现（radiomics_lite.py），无外部依赖
    auto        : 能 import radiomics 则用 pyradiomics，否则退回 lite

约定：返回的特征名统一为 "<图像类型>_<特征类>_<特征名>"，便于后续按前缀
拆分到 Conventional / Habitat 特征集。
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional, Sequence

import numpy as np

logger = logging.getLogger(__name__)

try:  # pragma: no cover
    import radiomics
    from radiomics import featureextractor

    _HAS_RADIOMICS = True
except Exception:  # noqa: BLE001
    _HAS_RADIOMICS = False


def backend_available(name: str = "pyradiomics") -> bool:
    return bool(_HAS_RADIOMICS) if name == "pyradiomics" else True


def resolve_backend(requested: str = "auto") -> str:
    if requested == "auto":
        return "pyradiomics" if _HAS_RADIOMICS else "lite"
    if requested == "pyradiomics" and not _HAS_RADIOMICS:
        logger.warning("未安装 PyRadiomics，自动回退到 lite 后端")
        return "lite"
    return requested


# ---------------------------------------------------------------------------
# PyRadiomics 后端
# ---------------------------------------------------------------------------


def _to_sitk(image: np.ndarray, mask: np.ndarray, spacing=(1.0, 1.0)):
    import SimpleITK as sitk

    img = sitk.GetImageFromArray(np.asarray(image, dtype=np.float32))
    msk = sitk.GetImageFromArray((np.asarray(mask) > 0).astype(np.uint8))
    img.SetSpacing(tuple(spacing) + (1.0,) if img.GetDimension() == 3 else tuple(spacing))
    msk.CopyInformation(img)
    return img, msk


def extract_pyradiomics(
    image: np.ndarray,
    mask: np.ndarray,
    params_file: str | Path,
    spacing=(1.0, 1.0),
) -> Dict[str, float]:
    """调用 PyRadiomics 提取特征。"""
    radiomics.setVerbosity(logging.ERROR)
    extractor = featureextractor.RadiomicsFeatureExtractor(str(params_file))
    img_sitk, msk_sitk = _to_sitk(image, mask, spacing=spacing)
    try:
        result = extractor.execute(img_sitk, msk_sitk, label=1)
    except Exception as exc:  # noqa: BLE001
        logger.warning("PyRadiomics 提取失败: %s", exc)
        return {}
    feats: Dict[str, float] = {}
    for key, value in result.items():
        if key.startswith("diagnostics"):
            continue
        try:
            feats[key] = float(value)
        except (TypeError, ValueError):
            continue
    return feats


# ---------------------------------------------------------------------------
# 统一入口
# ---------------------------------------------------------------------------


def extract_features(
    image: np.ndarray,
    mask: np.ndarray,
    cfg: dict,
    backend: str = "auto",
    include_shape: bool = True,
) -> Dict[str, float]:
    """按配置提取单张图像（单一生境子区）的特征。"""
    rad = cfg.get("radiomics", {})
    backend = resolve_backend(backend)
    bin_width = float(cfg.get("radiomics", {}).get("bin_width", 25.0))

    if backend == "pyradiomics":
        feats = extract_pyradiomics(
            image,
            mask,
            params_file=rad.get("params_file"),
            spacing=tuple(cfg.get("preprocess", {}).get("target_spacing", [1.0, 1.0])),
        )
        if include_shape:
            return feats
        return {k: v for k, v in feats.items() if "shape" not in k.lower()}

    from . import radiomics_lite as rl

    return rl.extract_all(
        image,
        mask,
        bin_width=bin_width,
        log_sigmas=tuple(rad.get("log_sigmas", [1.0, 2.0, 3.0])),
        wavelet=bool(rad.get("wavelet", True)),
        include_shape=include_shape,
    )


def prefix_features(feats: Dict[str, float], prefix: str) -> Dict[str, float]:
    """给特征名加前缀，用于区分模态（Color / US）与生境子区（H1_1 / H2_2）。"""
    return {f"{prefix}__{k}": v for k, v in feats.items()}


def count_features(feats: Dict[str, float], cfg: dict, warn_mismatch: bool = True) -> int:
    expected = int(cfg.get("radiomics", {}).get("expected_n_features", 0) or 0)
    n = len(feats)
    if warn_mismatch and expected and abs(n - expected) > 0.1 * expected:
        logger.warning("实际特征数 %d 与稿件记录的 %d 差异较大，请核对参数文件", n, expected)
    return n


def extract_habitat_features(
    image: np.ndarray,
    habitat_mask_dict: Dict[str, np.ndarray],
    cfg: dict,
    backend: str = "auto",
    modality: str = "",
    aggregate: str = "mean",
) -> Dict[str, float]:
    """对每个生境子区分别提取特征，并汇总为一个样本向量。

    汇总方式 aggregate:
        mean  : 各子区同名特征取均值（与常规影像组学「全肿瘤平均」对应）
        per_region : 保留每个子区单独的特征（列数随子区数变化，不建议直接建模）
        both  : 同时输出均值与各区特征
    """
    per_region: Dict[str, Dict[str, float]] = {}
    for name, m in habitat_mask_dict.items():
        if m.sum() == 0:
            continue
        per_region[name] = extract_features(image, m, cfg, backend=backend, include_shape=False)

    if not per_region:
        return {}

    out: Dict[str, float] = {}
    if aggregate in ("mean", "both"):
        keys = set.intersection(*[set(v.keys()) for v in per_region.values()]) if per_region else set()
        for k in sorted(keys):
            out[f"{modality}__HAB__{k}"] = float(np.mean([v[k] for v in per_region.values()]))
    if aggregate in ("per_region", "both"):
        for region, feats in per_region.items():
            for k, v in feats.items():
                out[f"{modality}__{region}__{k}"] = float(v)
    return out
