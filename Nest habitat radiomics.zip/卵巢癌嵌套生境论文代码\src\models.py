"""机器学习建模：9 种算法比较 + 5 折交叉验证网格搜索。

对应稿件 Methods「Machine-learning models」：
    LR / SVM / MLP / KNN / RandomForest / ExtraTrees / AdaBoost /
    GradientBoosting / LightGBM
    每个特征集（临床、Color、US、Habitat_Color、Habitat_US）分别比较，
    以三个队列的表现选出该特征集的最优基模型；超参数用训练集 5 折
    交叉验证网格搜索确定。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.ensemble import (
    AdaBoostClassifier,
    ExtraTreesClassifier,
    GradientBoostingClassifier,
    RandomForestClassifier,
)
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.naive_bayes import GaussianNB  # noqa: F401  (保留以便扩展)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from . import metrics

logger = logging.getLogger(__name__)

try:
    from lightgbm import LGBMClassifier

    _HAS_LGBM = True
except Exception:  # noqa: BLE001
    _HAS_LGBM = False


# ---------------------------------------------------------------------------
# 模型工厂
# ---------------------------------------------------------------------------


def available_algorithms() -> List[str]:
    base = ["LR", "SVM", "MLP", "KNN", "RandomForest", "ExtraTrees", "AdaBoost", "GradientBoosting"]
    return base + (["LightGBM"] if _HAS_LGBM else [])


# 需要先标准化输入再训练的算法（距离/梯度类）；树模型对量纲不敏感，保持原样
_SCALED_ALGORITHMS = {"LR", "SVM", "MLP", "KNN"}


def make_pipeline(name: str, estimator):
    """对量纲敏感的算法套一层 StandardScaler，返回 (pipeline, 参数前缀)。"""
    if name in _SCALED_ALGORITHMS:
        return Pipeline([("scaler", StandardScaler()), ("clf", estimator)]), "clf__"
    return estimator, ""


def build_estimator(name: str, params: Optional[dict] = None, random_state: int = 42):
    """按名称构造分类器；params 为网格搜索得到的超参数。"""
    p = dict(params or {})
    if name == "LR":
        return LogisticRegression(
            C=p.get("C", 1.0),
            penalty=p.get("penalty", "l2"),
            solver=p.get("solver", "lbfgs"),
            max_iter=p.get("max_iter", 2000),
            random_state=random_state,
        )
    if name == "SVM":
        return SVC(
            C=p.get("C", 1.0),
            gamma=p.get("gamma", "scale"),
            kernel=p.get("kernel", "rbf"),
            probability=True,
            random_state=random_state,
        )
    if name == "MLP":
        return MLPClassifier(
            hidden_layer_sizes=tuple(p.get("hidden_layer_sizes", (32, 16))),
            alpha=p.get("alpha", 1e-3),
            learning_rate_init=p.get("learning_rate_init", 1e-3),
            max_iter=2000,
            early_stopping=True,
            random_state=random_state,
        )
    if name == "KNN":
        return KNeighborsClassifier(
            n_neighbors=p.get("n_neighbors", 5),
            weights=p.get("weights", "uniform"),
            p=p.get("p", 2),
        )
    if name == "RandomForest":
        return RandomForestClassifier(
            n_estimators=p.get("n_estimators", 300),
            max_depth=p.get("max_depth", None),
            min_samples_leaf=p.get("min_samples_leaf", 1),
            n_jobs=-1,
            random_state=random_state,
        )
    if name == "ExtraTrees":
        return ExtraTreesClassifier(
            n_estimators=p.get("n_estimators", 300),
            max_depth=p.get("max_depth", None),
            min_samples_leaf=p.get("min_samples_leaf", 1),
            n_jobs=-1,
            random_state=random_state,
        )
    if name == "AdaBoost":
        return AdaBoostClassifier(
            n_estimators=p.get("n_estimators", 200),
            learning_rate=p.get("learning_rate", 1.0),
            random_state=random_state,
        )
    if name == "GradientBoosting":
        return GradientBoostingClassifier(
            n_estimators=p.get("n_estimators", 200),
            learning_rate=p.get("learning_rate", 0.1),
            max_depth=p.get("max_depth", 3),
            random_state=random_state,
        )
    if name == "LightGBM":
        if not _HAS_LGBM:
            raise ImportError("未安装 lightgbm")
        return LGBMClassifier(
            n_estimators=p.get("n_estimators", 200),
            learning_rate=p.get("learning_rate", 0.1),
            num_leaves=p.get("num_leaves", 31),
            verbose=-1,
            random_state=random_state,
        )
    raise ValueError(f"未知算法: {name}")


# ---------------------------------------------------------------------------
# 单模型训练：5 折网格搜索
# ---------------------------------------------------------------------------


@dataclass
class TrainedModel:
    name: str
    feature_set: str
    estimator: object
    best_params: dict
    cv_score: float
    train_scores: Dict[str, Dict[str, float]] = field(default_factory=dict)

    def predict_proba(self, X) -> np.ndarray:
        return self.estimator.predict_proba(np.asarray(X))[:, 1]

    @property
    def final_estimator(self):
        """去掉标准化层后的真实分类器（便于读取特征重要性/做 SHAP）。"""
        if isinstance(self.estimator, Pipeline):
            return self.estimator.steps[-1][1]
        return self.estimator

    def transformed(self, X) -> np.ndarray:
        """若外层是 Pipeline，返回经过前处理后的特征矩阵。"""
        Xv = np.asarray(X, dtype=float)
        if isinstance(self.estimator, Pipeline):
            return self.estimator[:-1].transform(Xv)
        return Xv


def train_model(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    name: str,
    cfg: dict,
    feature_set: str = "",
    n_folds: int = 5,
    random_state: int = 42,
) -> TrainedModel:
    """在训练集上做网格搜索（5 折、以 AUC 为准则），返回最优模型。"""
    spaces = (cfg.get("models", {}).get("search", {}) or {}).get(name, {})
    est, prefix = make_pipeline(name, build_estimator(name, random_state=random_state))
    if spaces:
        cv = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_state)
        search = GridSearchCV(
            est,
            param_grid={f"{prefix}{k}": list(v) for k, v in spaces.items()},
            scoring="roc_auc",
            cv=cv,
            n_jobs=-1,
            refit=True,
        )
        search.fit(X_train.values, y_train)
        model, params, score = search.best_estimator_, search.best_params_, float(search.best_score_)
    else:
        model = est.fit(X_train.values, y_train)
        params, score = {}, np.nan
    return TrainedModel(name=name, feature_set=feature_set, estimator=model,
                        best_params=params, cv_score=score)


def compare_algorithms(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    cohorts: Dict[str, Tuple[pd.DataFrame, np.ndarray]],
    cfg: dict,
    feature_set: str,
    algorithms: Optional[List[str]] = None,
    n_boot: int = 0,
) -> Tuple[pd.DataFrame, Dict[str, TrainedModel]]:
    """对同一特征集依次训练各算法，输出三队列指标表。"""
    algos = algorithms or cfg.get("models", {}).get("candidates", available_algorithms())
    algos = [a for a in algos if a != "LightGBM" or _HAS_LGBM]
    rows: List[dict] = []
    models: Dict[str, TrainedModel] = {}

    for name in algos:
        try:
            tm = train_model(
                X_train, y_train, name, cfg, feature_set,
                n_folds=int(cfg.get("cohort", {}).get("n_folds_cv", 5)),
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("[%s/%s] 训练失败: %s", feature_set, name, exc)
            continue
        models[name] = tm
        for cohort_name, (X, y) in cohorts.items():
            if X is None or len(X) == 0:
                continue
            prob = tm.predict_proba(X)
            m = metrics.classification_metrics(y, prob)
            if n_boot:
                _, lo, hi = metrics.bootstrap_auc_ci(y, prob, n_boot=n_boot)
                m["AUC_lower"], m["AUC_upper"] = lo, hi
            row = {"feature_set": feature_set, "model": name, "cohort": cohort_name,
                   "cv_auc": tm.cv_score, **m, "n": len(y)}
            rows.append(row)
    table = pd.DataFrame(rows)
    return table, models


def select_best_model(
    table: pd.DataFrame,
    models: Dict[str, TrainedModel],
    weights: Optional[Dict[str, float]] = None,
) -> Tuple[str, TrainedModel]:
    """以三个队列 AUC 的加权均值选最优基模型（默认等权）。"""
    if table.empty:
        raise RuntimeError("没有可用的模型结果")
    auc_wide = table.pivot_table(index="model", columns="cohort", values="AUC", aggfunc="mean")
    w = weights or {c: 1.0 for c in auc_wide.columns}
    score = sum(auc_wide[c].fillna(0) * w.get(c, 0) for c in auc_wide.columns) / sum(w.values())
    score = score.sort_values(ascending=False)
    best = score.index[0]
    return best, models[best]


# ---------------------------------------------------------------------------
# 临床单因素 / 多因素逻辑回归（稿件 Table 2）
# ---------------------------------------------------------------------------

try:  # 优先用 statsmodels（可直接给出 β、S.E、Wald Z）
    import statsmodels.api as sm

    _HAS_SM = True
except Exception:  # noqa: BLE001
    _HAS_SM = False


def _fit_logit(df: pd.DataFrame, outcome: str, variables: List[str]):
    """拟合逻辑回归，返回 (β 字典, 标准误字典, p 值字典, 系数向量, 截距)。"""
    y = df[outcome].astype(int).values
    X = df[variables].astype(float).values

    if _HAS_SM:
        x_sm = sm.add_constant(X, has_constant="add")
        fit = sm.Logit(y, x_sm).fit(disp=0)
        beta = {v: float(fit.params[i + 1]) for i, v in enumerate(variables)}
        se = {v: float(fit.bse[i + 1]) for i, v in enumerate(variables)}
        p = {v: float(fit.pvalues[i + 1]) for i, v in enumerate(variables)}
        return beta, se, p, np.asarray(fit.params[1:]), float(fit.params[0])

    # 回退：sklearn 拟合 + 正态近似标准误（基于设计矩阵）
    from sklearn.linear_model import LogisticRegression

    clf = LogisticRegression(max_iter=5000, C=1e6).fit(X, y)
    beta_vec = clf.coef_.ravel()
    intercept = float(clf.intercept_[0])
    p_hat = clf.predict_proba(X)[:, 1]
    Xd = np.column_stack([np.ones(len(X)), X])
    w = p_hat * (1 - p_hat) + 1e-9
    try:
        cov = np.linalg.inv((Xd * w[:, None]).T @ Xd)
        se_all = np.sqrt(np.diag(cov))
    except np.linalg.LinAlgError:
        se_all = np.full(Xd.shape[1], np.nan)
    beta = {v: float(beta_vec[i]) for i, v in enumerate(variables)}
    se = {v: float(se_all[i + 1]) for i, v in enumerate(variables)}
    p = {
        v: float(2 * stats_norm_sf(abs(beta[v] / se[v]))) if se[v] > 0 else np.nan
        for v in variables
    }
    return beta, se, p, beta_vec, intercept


def stats_norm_sf(z: float) -> float:
    from scipy import stats

    return float(stats.norm.sf(z))


def univariate_logistic(df: pd.DataFrame, outcome: str, variables: List[str]) -> pd.DataFrame:
    """逐个变量的单因素逻辑回归，返回 β、S.E、Z、P、OR(95%CI)。"""
    rows = []
    for var in variables:
        try:
            beta, se, p, _, _ = _fit_logit(df, outcome, [var])
        except Exception as exc:  # noqa: BLE001
            logger.warning("单因素逻辑回归失败(%s): %s", var, exc)
            continue
        b, s = beta[var], se[var]
        rows.append({
            "variable": var, "beta": b, "SE": s,
            "Z": b / s if s > 0 else np.nan, "P": p[var],
            "OR": np.exp(b), "OR_lower": np.exp(b - 1.96 * s), "OR_upper": np.exp(b + 1.96 * s),
        })
    return pd.DataFrame(rows).set_index("variable")


def multivariate_logistic(
    df: pd.DataFrame,
    outcome: str,
    variables: List[str],
    method: str = "backward",
    p_keep: float = 0.05,
) -> Tuple[pd.DataFrame, list]:
    """多因素逻辑回归（可选逐步后退法）。返回（结果表, 最终保留变量）。"""
    current = list(variables)
    while True:
        beta, se, pvals, _, _ = _fit_logit(df, outcome, current)
        if method != "backward" or len(current) == 1 or not pvals:
            break
        worst = max(pvals, key=lambda k: pvals[k] if np.isfinite(pvals[k]) else -1)
        if pvals[worst] <= p_keep:
            break
        current.remove(worst)

    beta, se, pvals, coef, intercept = _fit_logit(df, outcome, current)
    rows = []
    for var in current:
        b, s = beta[var], se[var]
        rows.append({
            "variable": var, "beta": b, "SE": s,
            "Z": b / s if s > 0 else np.nan, "P": pvals[var],
            "OR": np.exp(b), "OR_lower": np.exp(b - 1.96 * s), "OR_upper": np.exp(b + 1.96 * s),
        })
    return pd.DataFrame(rows).set_index("variable"), current
