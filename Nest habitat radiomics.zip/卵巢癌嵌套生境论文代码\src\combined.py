"""临床-生境联合模型。

对应稿件 Methods「Combined clinical-habitat model」：
    以逻辑回归把临床独立危险因素（年龄、FIGO 分期、Ki-67）与最优
    嵌套生境影像组学标签整合，得到联合模型；并绘制列线图（nomogram）。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

logger = logging.getLogger(__name__)


@dataclass
class CombinedModel:
    """联合模型（逻辑回归 + 标准化），并保存列线图所需的系数。"""

    model: Pipeline
    feature_names: List[str]
    coefficients: np.ndarray
    intercept: float

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        return self.model.predict_proba(X[self.feature_names].astype(float).values)[:, 1]

    def linear_predictor(self, X: pd.DataFrame) -> np.ndarray:
        Z = self.model.named_steps["scaler"].transform(X[self.feature_names].astype(float).values)
        return Z @ self.coefficients + self.intercept

    def odds_ratios(self) -> pd.DataFrame:
        return pd.DataFrame(
            {"feature": self.feature_names, "beta": self.coefficients, "OR": np.exp(self.coefficients)}
        ).set_index("feature")


def build_design_matrix(
    clinical: pd.DataFrame,
    labels: pd.DataFrame,
    clinical_vars: Sequence[str],
    label_cols: Sequence[str],
    id_col: str = "case_id",
) -> pd.DataFrame:
    """把临床变量与影像组学标签合并成建模矩阵（按病例号对齐）。"""
    left = clinical[[id_col] + [c for c in clinical_vars if c in clinical.columns]].copy()
    right = labels[[id_col] + [c for c in label_cols if c in labels.columns]].copy()
    merged = left.merge(right, on=id_col, how="inner")
    return merged


def fit_combined_model(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    feature_names: Optional[Sequence[str]] = None,
    max_iter: int = 5000,
) -> CombinedModel:
    """拟合联合逻辑回归模型。"""
    feats = list(feature_names or X_train.columns)
    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("lr", LogisticRegression(C=1e6, max_iter=max_iter, solver="lbfgs")),
    ]).fit(X_train[feats].astype(float).values, np.asarray(y_train).astype(int))

    lr = pipe.named_steps["lr"]
    coef = lr.coef_.ravel()
    intercept = float(lr.intercept_[0])
    return CombinedModel(model=pipe, feature_names=feats, coefficients=coef, intercept=intercept)


# ---------------------------------------------------------------------------
# 列线图（nomogram）
# ---------------------------------------------------------------------------


def nomogram_components(cm: CombinedModel, X_reference: pd.DataFrame) -> List[dict]:
    """计算列线图各变量的取值范围与分值刻度。

    由于模型内部做了标准化，列线图按原始尺度展示：
        每个变量的取值 → 标准化值 → 乘以系数得到该变量贡献的分值。
    """
    scaler: StandardScaler = cm.model.named_steps["scaler"]
    comps: List[dict] = []
    for i, name in enumerate(cm.feature_names):
        std = float(scaler.scale_[i]) or 1.0
        mean = float(scaler.mean_[i])
        raw_min = float(X_reference[name].min())
        raw_max = float(X_reference[name].max())
        # 该变量在原始尺度上的线性贡献：beta * (x - mean)/std
        contrib_min = cm.coefficients[i] * (raw_min - mean) / std
        contrib_max = cm.coefficients[i] * (raw_max - mean) / std
        comps.append({
            "feature": name,
            "raw_min": raw_min,
            "raw_max": raw_max,
            "mean": mean,
            "std": std,
            "beta": float(cm.coefficients[i]),
            "contribution_min": float(contrib_min),
            "contribution_max": float(contrib_max),
            "independent_risk": bool(cm.coefficients[i] > 0),
        })
    return comps


def nomogram_score(cm: CombinedModel, row: pd.Series) -> float:
    """按列线图规则计算单个病例的总分值（线性预测值 + 截距）。"""
    scaler: StandardScaler = cm.model.named_steps["scaler"]
    total = cm.intercept
    for i, name in enumerate(cm.feature_names):
        z = (float(row[name]) - float(scaler.mean_[i])) / (float(scaler.scale_[i]) or 1.0)
        total += cm.coefficients[i] * z
    return float(total)


def probability_from_score(score: float) -> float:
    return float(1.0 / (1.0 + np.exp(-score)))


# ---------------------------------------------------------------------------
# 三条候选联合模型
# ---------------------------------------------------------------------------


def candidate_combined_sets(
    clinical_vars: Sequence[str],
    state: dict,
) -> Dict[str, List[str]]:
    """返回稿件中比较的联合模型组合。

    state 中应含有各影像组学标签列名，如
        {"clinic": ["Age", "FIGO", "Ki67"],
         "color": ["Color_label"], "us": ["US_label"],
         "habitat_color": ["Habitat_Color_label"],
         "habitat_us": ["Habitat_US_label"]}
    """
    clinic = list(state.get("clinic", clinical_vars))
    out = {"Clinic": clinic}
    if state.get("color"):
        out["Clinic_Color"] = clinic + list(state["color"])
    if state.get("us"):
        out["Clinic_US"] = clinic + list(state["us"])
    if state.get("habitat_color"):
        out["Clinic_Habitat_Color"] = clinic + list(state["habitat_color"])
    if state.get("habitat_us"):
        out["Clinic_Habitat_US"] = clinic + list(state["habitat_us"])
    all_labels = list(state.get("color", [])) + list(state.get("us", [])) \
        + list(state.get("habitat_color", [])) + list(state.get("habitat_us", []))
    if all_labels:
        out["Combined"] = clinic + all_labels
    return out


def fit_all_combined(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    candidate_sets: Dict[str, List[str]],
) -> Dict[str, CombinedModel]:
    """对每个候选组合拟合一版联合模型。"""
    models: Dict[str, CombinedModel] = {}
    for name, feats in candidate_sets.items():
        avail = [f for f in feats if f in X_train.columns]
        if not avail:
            logger.warning("组合 %s 无可用变量，跳过", name)
            continue
        models[name] = fit_combined_model(X_train, y_train, feature_names=avail)
    return models
