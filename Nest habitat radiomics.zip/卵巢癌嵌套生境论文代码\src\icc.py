"""特征稳定性评价：观察者内 / 观察者间 ICC（组内相关系数）。

对应稿件 Methods「Tumor segmentation」：
    30 例随机抽样，reader 1 间隔两周重复勾画（intra-observer），
    reader 2 独立勾画（inter-observer）；双 ICC 均 > 0.8 的特征保留。
"""

from __future__ import annotations

from typing import Iterable, List, Sequence, Tuple

import numpy as np
import pandas as pd


def icc_2_1(matrix: np.ndarray) -> float:
    """计算 ICC(2,1)：双向随机效应、单一评分者、绝对一致性。

    matrix: (n_subjects, k_raters)
    """
    m = np.asarray(matrix, dtype=np.float64)
    if m.ndim != 2 or m.shape[0] < 2 or m.shape[1] < 2:
        return np.nan
    n, k = m.shape
    grand = m.mean()
    row_means = m.mean(axis=1)
    col_means = m.mean(axis=0)

    ss_row = k * ((row_means - grand) ** 2).sum()
    ss_col = n * ((col_means - grand) ** 2).sum()
    ss_total = ((m - grand) ** 2).sum()
    ss_err = ss_total - ss_row - ss_col

    msr = ss_row / (n - 1)
    msc = ss_col / (k - 1)
    mse = ss_err / ((n - 1) * (k - 1)) if (n - 1) * (k - 1) > 0 else np.nan

    denom = msr + (k - 1) * mse + k * (msc - mse) / n
    if denom <= 0:
        return np.nan
    return float((msr - mse) / denom)


def icc_table(df_a: pd.DataFrame, df_b: pd.DataFrame, prefix: str = "ICC") -> pd.DataFrame:
    """对同一批特征的两次测量结果，逐特征计算 ICC。

    df_a / df_b: index = 病例号，columns = 特征名，值 = 该特征提取结果
    """
    common = [c for c in df_a.columns if c in df_b.columns]
    rows: List[dict] = []
    for name in common:
        a = df_a[name].astype(float).values
        b = df_b[name].astype(float).values
        m = np.vstack([a, b]).T
        rows.append({prefix: icc_2_1(m), "feature": name})
    out = pd.DataFrame(rows).set_index("feature")
    return out


def select_stable_features(
    intra: pd.DataFrame,
    inter: pd.DataFrame,
    threshold: float = 0.8,
) -> Tuple[List[str], pd.DataFrame]:
    """返回（双 ICC 均 > 阈值的特征名, 合并后的 ICC 表）。"""
    merged = pd.concat(
        [intra.rename(columns={intra.columns[0]: "ICC_intra"}),
         inter.rename(columns={inter.columns[0]: "ICC_inter"})],
        axis=1,
    )
    merged["stable"] = (merged["ICC_intra"] > threshold) & (merged["ICC_inter"] > threshold)
    keep = merged.index[merged["stable"]].tolist()
    return keep, merged


def stability_report(
    features_by_repeat: Sequence[pd.DataFrame],
    labels: Sequence[str] = ("reader1_rep1", "reader1_rep2", "reader2"),
    threshold: float = 0.8,
) -> pd.DataFrame:
    """按多次重复提取结果生成稳定性报告（intra 用前两次，inter 用第 1 与第 3 次）。"""
    if len(features_by_repeat) < 3:
        raise ValueError("需要三次提取结果：reader1 两次 + reader2 一次")
    intra = icc_table(features_by_repeat[0], features_by_repeat[1], prefix="ICC_intra")
    inter = icc_table(features_by_repeat[0], features_by_repeat[2], prefix="ICC_inter")
    merged = pd.concat([intra, inter], axis=1)
    merged["stable"] = (merged["ICC_intra"] > threshold) & (merged["ICC_inter"] > threshold)
    return merged
