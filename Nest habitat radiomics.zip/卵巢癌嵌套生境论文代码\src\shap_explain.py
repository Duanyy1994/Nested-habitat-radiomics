"""SHAP 模型解释（稿件补充材料 Fig. S9）。"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline

logger = logging.getLogger(__name__)

try:
    import shap

    _HAS_SHAP = True
except Exception:  # noqa: BLE001
    _HAS_SHAP = False


def _to_2d(sv) -> np.ndarray:
    """把 SHAP 输出统一成 (n_samples, n_features)。

    不同解释器/模型版本的返回可能是 list[class]、3 维 (n, p, 1) 或 (n, p, n_class)，
    这里统一取正类（二分类的最后一维/最后一个元素）。
    """
    if isinstance(sv, list):
        sv = sv[1] if len(sv) > 1 else sv[0]
    sv = np.asarray(sv)
    if sv.ndim == 3:
        sv = sv[:, :, -1]
    if sv.ndim == 1:
        sv = sv.reshape(-1, 1)
    return sv


def shap_values(
    estimator,
    X: pd.DataFrame,
    background: Optional[pd.DataFrame] = None,
    max_background: int = 100,
    random_state: int = 42,
) -> Optional[np.ndarray]:
    """计算 SHAP 值；树模型用 TreeExplainer，其余用 KernelExplainer。"""
    if not _HAS_SHAP:
        logger.warning("未安装 shap，跳过 SHAP 分析（pip install shap）")
        return None

    Xv = np.asarray(X, dtype=float)
    if isinstance(estimator, Pipeline):
        est = estimator.steps[-1][1]
        Xv = estimator[:-1].transform(Xv)
    else:
        est = estimator
    try:
        if hasattr(est, "booster_") or est.__class__.__name__ in (
            "RandomForestClassifier", "ExtraTreesClassifier", "GradientBoostingClassifier",
            "AdaBoostClassifier", "LGBMClassifier",
        ):
            explainer = shap.TreeExplainer(est)
            return _to_2d(explainer.shap_values(Xv))
        bg = background if background is not None else X
        if len(bg) > max_background:
            bg = bg.sample(max_background, random_state=random_state)
        explainer = shap.KernelExplainer(est.predict_proba, np.asarray(bg, dtype=float))
        return _to_2d(explainer.shap_values(Xv))
    except Exception as exc:  # noqa: BLE001
        logger.warning("SHAP 计算失败: %s", exc)
        return None


def shap_summary(
    sv: np.ndarray,
    X: pd.DataFrame,
    path: str | Path,
    top_n: int = 20,
) -> Optional[str]:
    """绘制 SHAP 蜂群图（x 轴 SHAP 值，颜色表示特征取值大小）。"""
    if sv is None:
        return None
    import matplotlib.pyplot as plt
    import shap

    fig = plt.figure(figsize=(5.0, max(3.0, top_n * 0.28)))
    shap.summary_plot(sv, np.asarray(X, dtype=float), feature_names=[_s(n) for n in X.columns],
                      max_display=top_n, show=False)
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out.with_suffix(".png"), dpi=300, bbox_inches="tight")
    plt.close(fig)
    return str(out.with_suffix(".png"))


def shap_importance_table(sv: np.ndarray, X: pd.DataFrame) -> pd.DataFrame:
    """按平均绝对 SHAP 值排序的特征重要性表。"""
    if sv is None:
        return pd.DataFrame()
    mean_abs = np.abs(np.asarray(sv)).mean(axis=0).ravel()
    return (
        pd.DataFrame({"feature": list(X.columns), "mean_abs_shap": mean_abs})
        .sort_values("mean_abs_shap", ascending=False)
        .reset_index(drop=True)
    )


def _s(name: str, max_len: int = 34) -> str:
    return name if len(name) <= max_len else name[: max_len - 3] + "..."
