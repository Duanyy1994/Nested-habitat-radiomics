"""影像标签与免疫微环境标志物的探索性分析（稿件 Fig.6 与 Results 末段）。

输入免疫表（可选）需含列：
    case_id, label(0/1), score(模型输出/影像标签), CD20, CD68, CD163
    CD163_CD68_ratio 可由 CD163/CD68 自动计算
输出：
    组间 Mann-Whitney U 检验表
    Spearman 相关表（含 Pearson 复核）
    23 例队列内 AUC（bootstrap 95% CI）
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional, Sequence

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score

logger = logging.getLogger(__name__)


def load_immune_table(path: str | Path) -> pd.DataFrame:
    df = pd.read_excel(path) if str(path).lower().endswith((".xlsx", ".xls")) else pd.read_csv(path)
    df.columns = [str(c).strip() for c in df.columns]
    if "CD163_CD68_ratio" not in df.columns and {"CD163", "CD68"} <= set(df.columns):
        df["CD163_CD68_ratio"] = df["CD163"] / df["CD68"].replace(0, np.nan)
    return df


def group_comparison(
    df: pd.DataFrame,
    markers: Sequence[str],
    label_col: str = "label",
) -> pd.DataFrame:
    """复发 vs 未复发的免疫标志物比较（Mann-Whitney U）。"""
    rows = []
    for m in markers:
        if m not in df.columns:
            continue
        a = df.loc[df[label_col] == 1, m].dropna()
        b = df.loc[df[label_col] == 0, m].dropna()
        if a.size < 2 or b.size < 2:
            continue
        stat, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        rows.append({
            "marker": m,
            "recurrence_mean": float(a.mean()),
            "nonrecurrence_mean": float(b.mean()),
            "recurrence_median": float(a.median()),
            "nonrecurrence_median": float(b.median()),
            "U": float(stat),
            "p_value": float(p),
            "n_recurrence": int(a.size),
            "n_nonrecurrence": int(b.size),
        })
    return pd.DataFrame(rows).set_index("marker")


def correlation_analysis(
    df: pd.DataFrame,
    markers: Sequence[str],
    score_col: str = "score",
) -> pd.DataFrame:
    """模型输出与免疫标志物的 Spearman / Pearson 相关。"""
    rows = []
    for m in markers:
        if m not in df.columns:
            continue
        x = df[score_col].astype(float)
        y = df[m].astype(float)
        ok = x.notna() & y.notna()
        if ok.sum() < 5:
            continue
        rho, p_s = stats.spearmanr(x[ok], y[ok])
        r, p_p = stats.pearsonr(x[ok], y[ok])
        rows.append({
            "marker": m, "spearman_rho": float(rho), "spearman_p": float(p_s),
            "pearson_r": float(r), "pearson_p": float(p_p), "n": int(ok.sum()),
        })
    return pd.DataFrame(rows).set_index("marker")


def immune_cohort_auc(df: pd.DataFrame, score_col: str = "score", label_col: str = "label",
                      n_boot: int = 1000, random_state: int = 42) -> Dict[str, float]:
    """免疫子队列内的判别能力（AUC + bootstrap CI）。"""
    from .metrics import bootstrap_auc_ci

    y = df[label_col].astype(int).values
    s = df[score_col].astype(float).values
    auc, lo, hi = bootstrap_auc_ci(y, s, n_boot=n_boot, random_state=random_state)
    return {"AUC": auc, "AUC_lower": lo, "AUC_upper": hi, "n": int(len(y)),
            "n_recurrence": int(y.sum())}


def run_immune_analysis(
    immune_table: str | Path,
    cfg: dict,
    out_tables: str | Path,
    out_figures: str | Path,
    plot: bool = True,
) -> Dict[str, object]:
    """完整执行免疫分析并落盘。返回结果字典（表 + AUC）。"""
    from . import plotting

    df = load_immune_table(immune_table)
    markers = cfg.get("immune", {}).get(
        "markers", ["CD20", "CD68", "CD163", "CD163_CD68_ratio"]
    )
    group = group_comparison(df, markers)
    corr = correlation_analysis(df, markers)
    auc = immune_cohort_auc(df)

    out_tables = Path(out_tables)
    out_figures = Path(out_figures)
    out_tables.mkdir(parents=True, exist_ok=True)
    out_figures.mkdir(parents=True, exist_ok=True)

    group.to_csv(out_tables / "immune_group_comparison.csv", encoding="utf-8-sig")
    corr.to_csv(out_tables / "immune_correlation.csv", encoding="utf-8-sig")
    pd.Series(auc).to_csv(out_tables / "immune_cohort_auc.csv", encoding="utf-8-sig")

    if plot:
        pvals = group["p_value"].to_dict() if not group.empty else {}
        plotting.plot_group_boxplot(
            df, group_col="label", value_cols=[m for m in markers if m in df.columns],
            path=out_figures / "Fig6a_immune_group_boxplot", p_values=pvals,
        )
        # 相关性散点
        import matplotlib.pyplot as plt

        present = [m for m in markers if m in df.columns]
        if present:
            fig, axes = plt.subplots(1, len(present), figsize=(2.6 * len(present), 2.8), squeeze=False)
            for j, m in enumerate(present):
                ax = axes[0][j]
                ax.scatter(df[m], df["score"], s=14, color="#2e86c1")
                if m in corr.index:
                    ax.set_title(f"{m}\nrho={corr.loc[m, 'spearman_rho']:.2f}, p={corr.loc[m, 'spearman_p']:.3f}",
                                 fontsize=7)
                ax.set_xlabel(m)
                ax.set_ylabel("Model score")
            fig.savefig(out_figures / "Fig6b_immune_correlation.png", dpi=300, bbox_inches="tight")
            plt.close(fig)

    return {"group": group, "correlation": corr, "auc": auc}
