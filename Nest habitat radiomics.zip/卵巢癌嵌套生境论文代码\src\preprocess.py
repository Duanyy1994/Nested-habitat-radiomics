"""图像预处理：掩膜对齐、去噪、分辨率归一/重采样、ROI 内归一化。

对应稿件 Methods「Ultrasound image acquisition and preprocessing」：
    denoising -> resolution normalisation -> resampling to fixed spacing (1,1)
"""

from __future__ import annotations

import numpy as np
from scipy import ndimage


def align_mask_to_image(
    mask: np.ndarray,
    image_shape: tuple[int, int],
    threshold: float = 0.5,
    order: int = 0,
) -> np.ndarray:
    """把分割掩膜重采样到图像尺寸（最近邻），并二值化/保留标签。

    3D Slicer 导出的 Segment 掩膜常与导出的 JPG 尺寸不一致
    （本数据集掩膜 975×743、图像 640×480），此步必须在特征提取前完成。
    """
    mask = np.asarray(mask, dtype=np.float32)
    if mask.shape == tuple(image_shape):
        out = mask
    else:
        zoom = (
            image_shape[0] / mask.shape[0],
            image_shape[1] / mask.shape[1],
        )
        out = ndimage.zoom(mask, zoom, order=order, mode="nearest", prefilter=False)
        out = out[: image_shape[0], : image_shape[1]]
        if out.shape != tuple(image_shape):
            pad = np.zeros(image_shape, dtype=out.dtype)
            pad[: out.shape[0], : out.shape[1]] = out
            out = pad

    labels = np.unique(out[out > threshold])
    if labels.size <= 1 and (labels.size == 0 or labels[0] <= 1):
        return (out > threshold).astype(np.uint8)
    # 多标签（生境标签图）：四舍五入回整数标签
    return np.rint(out).astype(np.int32)


def denoise(image: np.ndarray, method: str = "median", kernel: int = 3, sigma: float = 1.0) -> np.ndarray:
    """去噪：中值滤波（默认，保边）或高斯滤波。"""
    img = np.asarray(image, dtype=np.float32)
    if method == "median":
        return ndimage.median_filter(img, size=kernel)
    if method == "gaussian":
        return ndimage.gaussian_filter(img, sigma=sigma)
    return img


def resample_to_spacing(
    image: np.ndarray,
    spacing_in: tuple[float, float],
    spacing_out: tuple[float, float],
    order: int = 1,
) -> np.ndarray:
    """按物理间距重采样到固定 spacing（默认 1 mm × 1 mm）。

    超声 JPG 无 DICOM 头，spacing_in 需由 config 给定（默认按扫描深度估算）。
    """
    zoom = (spacing_in[0] / spacing_out[0], spacing_in[1] / spacing_out[1])
    if np.allclose(zoom, 1.0):
        return np.asarray(image, dtype=np.float32)
    return ndimage.zoom(np.asarray(image, dtype=np.float32), zoom, order=order)


def normalize_resolution(
    image: np.ndarray,
    mask: np.ndarray,
    target_long_side: int = 512,
) -> tuple[np.ndarray, np.ndarray]:
    """分辨率归一：把长边缩放到统一像素数，抑制不同设备缩放带来的差异。"""
    h, w = image.shape
    long_side = max(h, w)
    if long_side == target_long_side:
        return image, mask
    scale = target_long_side / long_side
    new_h, new_w = int(round(h * scale)), int(round(w * scale))
    img = ndimage.zoom(np.asarray(image, dtype=np.float32), (new_h / h, new_w / w), order=1)
    msk = ndimage.zoom(np.asarray(mask, dtype=np.float32), (new_h / h, new_w / w), order=0)
    msk = (msk > 0.5).astype(np.uint8) if len(np.unique(msk)) <= 2 else np.rint(msk).astype(np.int32)
    return img, msk


def normalize_intensity(
    image: np.ndarray,
    mask: np.ndarray,
    method: str = "zscore_in_roi",
) -> np.ndarray:
    """强度归一化。默认在 ROI 内做 z-score，避免背景与耦合剂影响。"""
    img = np.asarray(image, dtype=np.float32)
    roi = img[mask > 0]
    if method == "none" or roi.size == 0:
        return img
    if method == "zscore_in_roi":
        mu, sd = float(roi.mean()), float(roi.std())
        return (img - mu) / (sd if sd > 1e-6 else 1.0)
    if method == "minmax":
        lo, hi = float(roi.min()), float(roi.max())
        return (img - lo) / (hi - lo if hi - lo > 1e-6 else 1.0)
    raise ValueError(f"未知归一化方式: {method}")


def crop_to_roi(image: np.ndarray, mask: np.ndarray, margin: int = 10):
    """裁到 ROI 外接框（带 margin），减少计算量并去除无关区域。"""
    ys, xs = np.where(mask > 0)
    if ys.size == 0:
        return image, mask, (0, 0, image.shape[0], image.shape[1])
    y0 = max(int(ys.min()) - margin, 0)
    y1 = min(int(ys.max()) + margin + 1, image.shape[0])
    x0 = max(int(xs.min()) - margin, 0)
    x1 = min(int(xs.max()) + margin + 1, image.shape[1])
    return image[y0:y1, x0:x1], mask[y0:y1, x0:x1], (y0, y1, x0, x1)


def preprocess_image(
    image: np.ndarray,
    mask: np.ndarray,
    cfg: dict,
) -> tuple[np.ndarray, np.ndarray]:
    """完整预处理链：对齐掩膜 → 去噪 → 分辨率归一 → 重采样 → 归一化。"""
    p = cfg.get("preprocess", {})
    spacing_out = tuple(p.get("target_spacing", [1.0, 1.0]))
    spacing_in = tuple(p.get("spacing_in", [spacing_out[0], spacing_out[1]]))

    mask = align_mask_to_image(
        mask,
        image.shape,
        threshold=float(p.get("mask_threshold", 0.5)),
        order=0 if p.get("mask_interp", "nearest") == "nearest" else 1,
    )
    img = denoise(
        image,
        method=p.get("denoise", "median"),
        kernel=int(p.get("denoise_kernel", 3)),
        sigma=float(p.get("gaussian_sigma", 1.0)),
    )
    img, mask = normalize_resolution(
        img, mask, target_long_side=int(p.get("target_long_side", 512))
    )
    img = resample_to_spacing(img, spacing_in=spacing_in, spacing_out=spacing_out, order=1)
    mask = resample_to_spacing(mask, spacing_in=spacing_in, spacing_out=spacing_out, order=0)
    mask = (mask > 0.5).astype(np.uint8)
    img = normalize_intensity(img, mask, method=p.get("normalize", "zscore_in_roi"))
    return img, mask
