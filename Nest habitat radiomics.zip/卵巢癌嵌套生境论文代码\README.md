# 卵巢癌双模态超声「嵌套生境」影像组学 —— 论文代码包

对应稿件：**Nested habitat ultrasound predicts ovarian cancer 3-year recurrence**
（双模态超声嵌套生境影像组学预测卵巢癌术后 3 年复发）

本代码包按稿件 Methods 逐条重建了整套分析流程：队列构建 → 影像预处理 → 嵌套生境分割 →
影像组学特征提取 → 特征筛选与标签构建 → 9 种机器学习算法比较 → 临床-生境联合模型与模型比较 →
免疫微环境探索分析。所有步骤均可在本机直接运行并输出表格与图片。

---

## 1. 目录结构

```
论文代码/
├── config.yaml                    # 全局配置（路径、队列、预处理、筛选、建模、评价）
├── requirements.txt               # Python 依赖
├── run_pipeline.py                # 主入口：--step 1..6 / all
├── configs/
│   └── radiomics_params.yaml      # PyRadiomics 参数（binWidth=25、LoG、Wavelet）
├── src/
│   ├── config.py                  # 配置加载、随机种子
│   ├── io_utils.py                # NRRD/JPG 读取、临床表解析、队列划分
│   ├── preprocess.py              # 掩膜对齐、去噪、重采样、强度归一化
│   ├── habitat.py                 # 5×5 局部特征 + 两轮 K-means 嵌套生境
│   ├── radiomics_lite.py          # 纯 numpy 特征引擎（PyRadiomics 不可用时的后备）
│   ├── radiomics_extraction.py    # 特征提取后端调度（pyradiomics / lite）
│   ├── icc.py                     # ICC(2,1) 一致性检验与稳定特征筛选
│   ├── feature_selection.py       # 正态性检验 + t/Mann-Whitney + 相关性 + mRMR + LASSO
│   ├── models.py                  # 9 种算法、5 折交叉验证网格搜索、逻辑回归封装
│   ├── metrics.py                 # AUC/灵敏度/特异度、校准、Hosmer-Lemeshow、DCA、DeLong、NRI、IDI
│   ├── combined.py                # 联合模型、列线图
│   ├── plotting.py                # 全部图件（300 dpi png + svg，中文字体）
│   ├── shap_explain.py            # SHAP 蜂群图与重要性表
│   └── immune_analysis.py         # 免疫组化分组比较与相关性
├── scripts/                       # 分步一键脚本（Windows 双击即可）
└── outputs/
    ├── tables/                    # 所有结果表
    ├── figures/                   # 所有图件
    ├── features/                  # 特征表与筛选后的特征矩阵
    └── habitat_masks/             # 每例每模态的一级/二级生境掩膜
```

---

## 2. 运行环境

- Python 3.8+（本机实测 3.13；稿件记录为 3.7.12）
- 必需：`numpy pandas scipy scikit-learn matplotlib openpyxl pillow`
- 可选：`SimpleITK`（仅 PyRadiomics 后端需要）、`lightgbm`（LightGBM 算法）、
  `shap`（SHAP 图）、`statsmodels`（逻辑回归标准误更精确）、`pyradiomics`（首选特征引擎）

```powershell
pip install -r requirements.txt
cd "论文代码"
python run_pipeline.py --step 1        # 先确认数据能被正确读入
```

---

## 3. 原始数据放置要求

`config.yaml → paths` 中配置三个路径：

| 配置项 | 说明 |
|---|---|
| `image_root` | 内部队列影像根目录，结构为 `<根>/<病例号>/<彩色|黑白>/images/<病例号>.jpg` 与 `masks/<病例号>.nrrd` |
| `external_image_root` | 外部验证队列影像根目录，结构同上；无独立目录时留空 |
| `clinical_table` + `clinical_sheet` | 临床/病理/随访汇总表（Excel）及其内部队列表名 |
| `clinical_sheet_external` | 外部队列所在的表名（可为同一 Excel 的另一张表） |

临床表至少需要这些列（列名可在 `config.yaml → cohort` 中改）：
`Code`（病例号）、`Status`（1/2 复发状态）、`Time`（随访月）、`Age`、`Size`、`FIGO`、
`Menopausal status`、`Vaginal bleeding`、`CA125`、`CA199`、`HE4`、`AFP`、`Ki67`。

> ⚠️ **病例号偏移**：内部与外部目录的病例号常常重号（本数据两者都是 1 起编号）。
> 代码对外部队列统一加 `cohort.external_id_offset`（默认 10000），原始号保存在 `source_id` 列，
> 避免 merge 时互相污染。若你的数据不会重号，把该值设为 0 即可。

---

## 4. 分步说明

| 步骤 | 命令 | 产出 |
|---|---|---|
| 1 | `python run_pipeline.py --step 1` | `outputs/tables/cohort.csv`、`Table1_baseline.csv` |
| 2 | `python run_pipeline.py --step 2 --workers 6` | 特征表、生境掩膜、生境示例图 |
| 3 | `python run_pipeline.py --step 3` | 单因素检验表、相关性热图、LASSO 曲线/系数、`radiomics_labels.csv` |
| 4 | `python run_pipeline.py --step 4` | 9 种算法 × 5 个特征集 × 3 队列的指标表、ROC、SHAP |
| 5 | `python run_pipeline.py --step 5` | 联合模型、校准曲线、DCA、列线图、DeLong/NRI/IDI |
| 6 | `python run_pipeline.py --step 6` | 免疫分组比较、相关性、免疫队列 AUC（Fig 6） |
| 全部 | `python run_pipeline.py --step all` | 上述全部 |

调试参数：

- `--limit N`：每个队列只取前 N 例（快速跑通流程）
- `--workers N`：Step 2 并行进程数（0 = 自动取 CPU 核数-1，1 = 串行）
- `--backend auto|lite|pyradiomics`：特征引擎。`auto` 优先 PyRadiomics，缺失时自动回退 lite
- `--fast`：Step 4 只比较 4 种算法

`scripts/` 下另有 `01_队列.bat` … `06_免疫分析.bat`，双击等价于上述命令。

---

## 5. 方法学实现要点（与稿件 Methods 对应）

1. **掩膜读取**：3D Slicer 导出的 NRRD 数据按 **Fortran 顺序**存储，必须 `order="F"` 还原
   （否则二维掩膜会被打散成上百个碎片，`src/io_utils.py` 已处理）。
2. **掩膜与图像空间不一致**（975×743 vs 640×480）→ 最近邻重采样到图像尺寸后再提取特征。
3. **强度归一化**：ROI 内 z-score；**特征提取前**再把每类图像（含 LoG、小波子带）ROI 强度
   线性映射到 0–255，然后用 `binWidth=25` 离散化（约 10 个灰阶）。超声没有 CT 式绝对 HU 单位，
   若直接在 z-score 尺度上用 binWidth=25 会把 ROI 压成 1 个灰阶、纹理特征全部失效。
4. **嵌套生境**：5×5 滑窗逐像素算 8 个局部特征（mean/std/range/entropy/skewness/contrast/
   homogeneity/energy）→ 标准化 → 第一轮 K-means（k∈2..6，CH 分数选 k）→ 取面积最大的
   一级生境子区 → 第二轮 K-means（k∈2..4，同样 CH 分数）→ 二级子生境。
   像素数超过 `habitat.sample_pixels`（默认 20000）时先随机抽样拟合质心，再对全 ROI 预测，
   保证聚类稳定且耗时可控。
5. **特征筛选**：训练集内 z-score → 正态性检验（Shapiro）决定 t 检验或 Mann-Whitney U（p<0.05）
   → |Pearson r|>0.9 去冗余 → mRMR（互信息商）预筛 → 10 折交叉验证 `LassoCV` 取
   `mse_1se` 最简模型 → 非零系数特征即为核心特征，其线性预测值 z-score 化为影像组学标签。
6. **建模**：9 种算法统一走 `StratifiedKFold(5)` + `GridSearchCV(scoring="roc_auc")`，
   每个特征集按训练/内部测试/外部验证三队列的 AUC 等权均值选最优算法。
7. **模型比较**：DeLong 检验、连续 NRI、IDI；校准曲线 + Hosmer-Lemeshow；DCA 净收益。
8. **逻辑回归**：优先 `statsmodels`（有标准误与 p 值）；未安装时用 sklearn + 设计矩阵求逆近似标准误，
   单因素/多因素（后退法）结论一致可用。

---

## 6. 与稿件的差异说明（务必先读）

| 项目 | 稿件 | 本代码默认 | 说明 |
|---|---|---|---|
| 样本量 | 522 例（内部 402 + 外部 120） | 本机可用表为内部 171 + 外部 120 = 291 | 项目目录里的临床表（`生境 补充表1` 171 行 / `无瘤生存期` 120 行）不含 402 例内部队列。把 `config.yaml` 指向完整队列表后即可复现稿件规模，代码无需改动。 |
| 每模态特征数 | 1561（PyRadiomics） | 702（lite 后端） | 本机 Python 3.13 无 PyRadiomics 轮子（源码编译失败），故自带纯 numpy 引擎，覆盖 shape2D/firstorder/GLCM/GLRLM/GLSZM/GLDM/NGTDM + LoG(σ=1,2,3) + Haar 小波，但矩阵项数少于 PyRadiomics（如 GLCM 24 项 vs 24、小波子带仅 LL/LH/HL/HH 4 组而非 8 组）。换到能装 PyRadiomics 的环境后 `--backend pyradiomics` 即按 `configs/radiomics_params.yaml`（binWidth 25、force2D、LoG σ=1,2,3、Wavelet）复现 1561 维。 |
| ICC 复勾 | 30 例双医师复勾、双 ICC>0.8 | 若 `paths.icc_table` 留空则跳过 | 需要你提供每例两次勾画的重复掩膜或重复特征表；表结构见 `src/icc.py` 的 `icc_table` 说明。 |
| 免疫队列 | 23 例独立队列 + CD20/CD68/CD163 | 若 `paths.immune_table` 留空则跳过 | 同理需要 23 例的免疫组化表（列：病例号、模型输出、CD20、CD68、CD163）。 |
| 标签方向 | Status：未复发/复发 | `label_map: {1: 0, 2: 1}` | 按本机表 `Status` 取值 1/2 推测（1=未复发、2=复发）。若你的表是相反编码，改 `config.yaml → cohort.label_map`。 |
| 图片输出 | 稿件图件 | 300 dpi png + svg | 与稿件版式不同，但统计口径一致。 |

---

## 7. 本机实跑结果（2026-11-11，lite 后端，291 例）

全流程已在本机真实数据上跑通，产物见 `outputs/`：

| 队列 | 例数 | 复发 |
|---|---|---|
| 训练集 | 119 | 20 |
| 内部测试集 | 52 | 9 |
| 外部验证集 | 120 | 25 |
| 合计 | 291 | 54 |

特征维度：常规 Color/US 各 702 维、生境 Habitat_Color/Habitat_US 各 702 维（lite 后端）。

LASSO 保留的核心特征数（训练集内）：

| 特征集 | 入模特征 | 单因素保留 | 去冗余后 | LASSO 核心 |
|---|---|---|---|---|
| Color | 686 | 50 | 21 | 20 |
| US | 686 | 31 | 17 | 11 |
| Habitat_Color | 673 | 138 | 39 | 17 |
| Habitat_US | 673 | 15 | 9 | 9 |

9 种算法中最优基模型（按三队列 AUC 等权均值选）与 AUC：

| 特征集 | 最优算法 | 训练集 | 内部测试 | 外部验证 |
|---|---|---|---|---|
| Clinic | AdaBoost | 0.999 | 0.873 | 0.799 |
| Color | RandomForest | 0.999 | 0.734 | 0.584 |
| US | GradientBoosting | 0.999 | 0.721 | 0.536 |
| Habitat_Color | GradientBoosting | 1.000 | 0.693 | 0.585 |
| Habitat_US | AdaBoost | 1.000 | 0.716 | 0.464 |

联合模型（逻辑回归整合临床 + 各影像组学标签）：训练集 AUC 0.992、内部测试 0.829、外部验证 0.755
（bootstrap 95% CI 见 `outputs/tables/combined_model_performance.csv`）。

> ⚠️ 这些数字**不等于**稿件报告的数值（联合模型 AUC 0.89–0.91）。原因有三，且都可控：
> ① 本机临床表只有 171+120 例，训练集仅 119 例，远小于稿件的 281 例；
> ② lite 后端特征维度（702）低于 PyRadiomics 的 1561，纹理刻画更粗；
> ③ `Status` 的 1/2 与复发方向的对应关系是按表内取值推测的，请与你的随访表核对。
> 若把 `config.yaml` 指向完整队列、并在能装 PyRadiomics 的环境用 `--backend pyradiomics` 重跑，
> 即可逐项逼近稿件数值。

运行耗时参考（12 逻辑核）：Step 2 共 578 个（病例×模态）任务，10 进程并行 42.2 分钟；
Step 3 约 10 秒；Step 4（9 算法 × 5 特征集 × 5 折网格搜索）约 6 分钟；Step 5 约 1 分钟。

---

## 8. 常见问题

- **Step 2 很慢**：单例单模态约 10–20 s（生境两轮 K-means 占大头）。291 例 × 2 模态、6 进程约 25 min；
  全量 522 例建议 `--workers` 设为物理核数，或分队列分批跑。
- **PowerShell 里报 `NativeCommandError`**：这是 python 的 stderr 日志被 PowerShell 当作错误流，
  不是运行失败。用 `python ... *> run.log` 把日志重定向到文件即可。
- **LightGBM/SHAP 缺失**：代码自动跳过对应算法/图件，不影响其他步骤。
- **mask 读出来全是碎片**：说明 NRRD 未按 Fortran 顺序读取，请用本包的 `io_utils.read_nrrd`。
