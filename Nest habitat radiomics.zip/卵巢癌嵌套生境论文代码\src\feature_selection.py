"""特征筛选流水线。

严格按稿件 Methods「Conventional radiomics feature extraction and selection」：
    1. 全部特征标准化（只用训练集拟合，避免信息泄漏）；
    2. 独立样本 t 检验 或 Mann-Whitney U 检验，保留 p < 0.05 的特征；
    3. Pearson 相关分析 + mRMR，剔除 |r| > 0.9 的冗余特征；
    4. 10 折交叉验证 LASSO 回归压缩系数，保留系数非零的核心特征，
       并据此构建影像组学标签（radiomics label）。

注意：所有步骤只在训练集上拟合，再 apply 到内部测试集与外部验证集。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.feature_selection import mutual_info_classif
from sklearn.linear_model import Lasso, LassoCV
from sklearn.preprocessing import StandardScaler

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 步骤 1：标准化
# ---------------------------------------------------------------------------


def fit_scaler(X: pd.DataFrame, cfg: dict) -> StandardScaler:
    method = cfg.get("feature_selection", {}).get("standardize", "zscore")
    if method != "zscore":
        logger.warning("当前仅实现 z-score 标准化，参数 %s 被忽略", method)
    return StandardScaler().fit(X.values)


def apply_scaler(scaler: StandardScaler, X: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame(scaler.transform(X.values), index=X.index, columns=X.columns)


# ---------------------------------------------------------------------------
# 步骤 2：组间差异检验
# ---------------------------------------------------------------------------


def _is_normal(values: np.ndarray) -> bool:
    values = np.asarray(values, dtype=float)
    if values.size < 8:
        return stats.shapiro(values).pvalue > 0.05 if values.size >= 3 else False
    # 大样本用偏度/峰度快速判断，避免 shapiro 对大样本不敏感
    sk = stats.skew(values)
    ku = stats.kurtosis(values)
    return abs(sk) < 1 and abs(ku) < 2


def univariate_filter(
    X: pd.DataFrame,
    y: np.ndarray,
    p_threshold: float = 0.05,
    method: str = "auto",
) -> pd.DataFrame:
    """返回每个特征在两组的检验结果（p 值、检验方法、组均值）。"""
    rows: List[dict] = []
    g1 = y == 1
    g0 = y == 0
    for col in X.columns:
        v = X[col].values.astype(float)
        a, b = v[g1], v[g0]
        use_t = method == "t" or (method == "auto" and _is_normal(a) and _is_normal(b))
        if use_t:
            stat, p = stats.ttest_ind(a, b, equal_var=False, nan_policy="omit")
            test = "t-test"
        else:
            stat, p = stats.mannwhitneyu(a, b, alternative="two-sided")
            test = "Mann-Whitney U"
        rows.append(
            {
                "feature": col,
                "p_value": float(p),
                "test": test,
                "mean_recurrence": float(np.nanmean(a)),
                "mean_nonrecurrence": float(np.nanmean(b)),
            }
        )
    out = pd.DataFrame(rows).set_index("feature")
    out["selected_univariate"] = out["p_value"] < p_threshold
    return out


# ---------------------------------------------------------------------------
# 步骤 3：相关性去冗余 + mRMR
# ---------------------------------------------------------------------------


def remove_highly_correlated(
    X: pd.DataFrame,
    importance: Optional[pd.Series] = None,
    threshold: float = 0.9,
) -> List[str]:
    """按重要性贪心保留特征，剔除与之 |r| > threshold 的特征。"""
    if X.shape[1] <= 1:
        return list(X.columns)
    corr = X.corr(method="pearson").abs().values
    cols = list(X.columns)
    order = (
        importance.reindex(cols).fillna(0).sort_values(ascending=False).index.tolist()
        if importance is not None
        else cols
    )
    keep: List[str] = []
    for name in order:
        i = cols.index(name)
        if all(corr[i, cols.index(k)] <= threshold for k in keep):
            keep.append(name)
    return keep


def _mutual_info(X: pd.DataFrame, y: np.ndarray, random_state: int = 42) -> pd.Series:
    mi = mutual_info_classif(X.values, y, random_state=random_state)
    return pd.Series(mi, index=X.columns)


def mrmr_select(
    X: pd.DataFrame,
    y: np.ndarray,
    n_features: int = 100,
    method: str = "miq",
    random_state: int = 42,
) -> List[str]:
    """mRMR（最小冗余最大相关）特征选择。

    miq : 以 相关性 - 冗余 的商式准则增量选择
    mid : 以 相关性 - 冗余 的差值准则增量选择
    """
    if X.shape[1] <= n_features:
        return list(X.columns)
    relevance = _mutual_info(X, y, random_state=random_state)
    selected = [relevance.idxmax()]
    cand = [c for c in X.columns if c != selected[0]]
    # 冗余度用特征间 |Pearson r| 衡量（与稿件「相关性 + mRMR」口径一致）
    redundancy = X.corr().abs()

    while len(selected) < min(n_features, X.shape[1]) and cand:
        red = redundancy.loc[cand, selected].mean(axis=1)
        score = relevance.loc[cand]
        if method == "miq":
            crit = score / (red + 1e-6)
        else:
            crit = score - red
        best = crit.idxmax()
        selected.append(best)
        cand.remove(best)
    return selected


# ---------------------------------------------------------------------------
# 步骤 4：LASSO
# ---------------------------------------------------------------------------


def lasso_select(
    X: pd.DataFrame,
    y: np.ndarray,
    n_folds: int = 10,
    selection: str = "mse_1se",
    max_iter: int = 5000,
    random_state: int = 42,
) -> Tuple[List[str], np.ndarray, np.ndarray, pd.DataFrame]:
    """10 折交叉验证 LASSO，返回（保留特征、系数、截距、路径表）。

    selection:
        mse_min : 取交叉验证 MSE 最小的 alpha
        mse_1se : 取「1 个标准误」准则下的最简模型（更稳健，稿件常用）
    """
    cv = LassoCV(
        cv=n_folds,
        max_iter=max_iter,
        random_state=random_state,
        alphas=100,
        fit_intercept=True,
    ).fit(X.values, y)

    alphas = cv.alphas_
    mse = cv.mse_path_.mean(axis=1)
    se = cv.mse_path_.std(axis=1) / np.sqrt(cv.mse_path_.shape[1])

    if selection == "mse_min":
        alpha = float(cv.alpha_)
    else:
        best_idx = int(np.argmin(mse))
        thresh = mse[best_idx] + se[best_idx]
        candidates = np.flatnonzero(mse <= thresh)
        alpha = float(alphas[candidates.max()]) if candidates.size else float(cv.alpha_)

    model = Lasso(alpha=alpha, max_iter=max_iter, fit_intercept=True).fit(X.values, y)
    coef = model.coef_
    keep_mask = coef != 0
    keep = [c for c, m in zip(X.columns, keep_mask) if m]
    path = pd.DataFrame({"alpha": alphas, "mse": mse, "mse_se": se})
    return keep, coef[keep_mask], np.array([model.intercept_]), path


# ---------------------------------------------------------------------------
# 完整流程封装
# ---------------------------------------------------------------------------


@dataclass
class FeatureSelector:
    """一次特征筛选的完整状态，可复用于测试集/外部验证集。"""

    feature_names: List[str] = field(default_factory=list)
    input_features: List[str] = field(default_factory=list)
    scaler: Optional[StandardScaler] = None
    lasso_coef: Optional[np.ndarray] = None
    lasso_intercept: Optional[float] = None
    score_mean: float = 0.0
    score_std: float = 1.0
    tables: Dict[str, pd.DataFrame] = field(default_factory=dict)

    # ---- 构建标签 ----
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """返回标准化后的保留特征（X 需包含训练时用过的全部特征列）。"""
        if not self.feature_names:
            raise RuntimeError("特征筛选尚未拟合")
        X = X.reindex(columns=self.input_features)
        Z = pd.DataFrame(
            self.scaler.transform(X.values),
            index=X.index,
            columns=self.input_features,
        )
        return Z[self.feature_names]

    def label(self, X: pd.DataFrame) -> np.ndarray:
        """影像组学标签：LASSO 线性预测值做 z-score 标准化。"""
        Z = self.transform(X)
        raw = Z.values @ self.lasso_coef + self.lasso_intercept
        return (raw - self.score_mean) / (self.score_std if self.score_std > 1e-6 else 1.0)

    def summary(self) -> pd.DataFrame:
        return pd.DataFrame(
            {"feature": self.feature_names, "coefficient": self.lasso_coef}
        ).assign(abs_coefficient=lambda d: d["coefficient"].abs()).sort_values(
            "abs_coefficient", ascending=False
        )


def fit_selector(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    cfg: dict,
    verbose: bool = True,
) -> FeatureSelector:
    """在训练集上执行完整四步筛选。"""
    fs = cfg.get("feature_selection", {})
    sel = FeatureSelector()
    sel.input_features = list(X_train.columns)

    # 1) 标准化
    sel.scaler = fit_scaler(X_train, cfg)
    Z = apply_scaler(sel.scaler, X_train)

    # 2) 单因素检验
    uni = univariate_filter(
        Z,
        y_train,
        p_threshold=float(fs.get("univariate_p", 0.05)),
        method=fs.get("univariate_test", "auto"),
    )
    sel.tables["univariate"] = uni
    keep1 = uni.index[uni["selected_univariate"]].tolist()
    if verbose:
        logger.info("单因素检验保留 %d / %d 个特征", len(keep1), X_train.shape[1])
    if not keep1:
        raise RuntimeError("单因素检验后无特征保留，请放宽阈值或检查数据")

    # 3) 相关性 + mRMR
    Z1 = Z[keep1]
    if fs.get("use_mrmr", True):
        mr = mrmr_select(
            Z1,
            y_train,
            n_features=int(fs.get("mrmr_n_features", 100)),
            method=fs.get("mrmr_method", "miq"),
        )
        Z1 = Z1[mr]
    keep2 = remove_highly_correlated(
        Z1,
        importance=_mutual_info(Z1, y_train),
        threshold=float(fs.get("correlation_threshold", 0.9)),
    )
    sel.tables["after_redundancy"] = pd.DataFrame({"feature": keep2})
    if verbose:
        logger.info("去冗余后保留 %d 个特征", len(keep2))

    # 4) LASSO
    keep3, coef, intercept, path = lasso_select(
        Z[keep2],
        y_train,
        n_folds=int(fs.get("lasso_cv_folds", 10)),
        selection=fs.get("lasso_selection", "mse_1se"),
    )
    sel.tables["lasso_path"] = path
    if verbose:
        logger.info("LASSO 保留 %d 个核心特征", len(keep3))
    if not keep3:
        raise RuntimeError("LASSO 未保留任何特征，请检查 alpha 选择")

    sel.feature_names = keep3
    sel.lasso_coef = coef
    sel.lasso_intercept = float(intercept[0])

    raw_train = sel.transform(X_train).values @ coef + sel.lasso_intercept
    sel.score_mean = float(np.mean(raw_train))
    sel.score_std = float(np.std(raw_train)) or 1.0
    return sel
