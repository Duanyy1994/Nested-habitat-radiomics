"""模型评价指标：判别、校准、临床效用与模型比较。

含：
    AUC（含 bootstrap 置信区间）、准确度、敏感度、特异度、PPV、NPV、F1
    校准曲线数据 + Hosmer-Lemeshow 检验
    决策曲线分析（DCA）
    DeLong 检验（两条 ROC 的 AUC 差异）
    NRI（净重分类改善，连续型）与 IDI（综合判别改善）
"""

from __future__ import annotations

from typing import Dict, Optional, Sequence, Tuple

import numpy as np
from scipy import stats
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)


# ---------------------------------------------------------------------------
# 基本判别指标
# ---------------------------------------------------------------------------


def classification_metrics(
    y_true: np.ndarray,
    y_score: np.ndarray,
    threshold: float = 0.5,
) -> Dict[str, float]:
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score, dtype=float)
    y_pred = (y_score >= threshold).astype(int)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)
    sens = tp / (tp + fn) if (tp + fn) else np.nan
    spec = tn / (tn + fp) if (tn + fp) else np.nan
    ppv = tp / (tp + fp) if (tp + fp) else np.nan
    npv = tn / (tn + fn) if (tn + fn) else np.nan
    return {
        "AUC": float(roc_auc_score(y_true, y_score)) if len(np.unique(y_true)) > 1 else np.nan,
        "Accuracy": float(accuracy_score(y_true, y_pred)),
        "Sensitivity": float(sens),
        "Specificity": float(spec),
        "PPV": float(ppv),
        "NPV": float(npv),
        "F1": float(f1_score(y_true, y_pred, zero_division=0)),
        "TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp),
    }


def bootstrap_auc_ci(
    y_true: np.ndarray,
    y_score: np.ndarray,
    n_boot: int = 1000,
    alpha: float = 0.05,
    random_state: int = 42,
) -> Tuple[float, float, float]:
    """AUC 及其 bootstrap 置信区间。"""
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score, dtype=float)
    auc = roc_auc_score(y_true, y_score)
    rs = np.random.RandomState(random_state)
    vals = []
    n = y_true.size
    for _ in range(n_boot):
        idx = rs.randint(0, n, n)
        if len(np.unique(y_true[idx])) < 2:
            continue
        vals.append(roc_auc_score(y_true[idx], y_score[idx]))
    lo, hi = np.percentile(vals, [100 * alpha / 2, 100 * (1 - alpha / 2)]) if vals else (np.nan, np.nan)
    return float(auc), float(lo), float(hi)


# ---------------------------------------------------------------------------
# 校准
# ---------------------------------------------------------------------------


def calibration_data(y_true: np.ndarray, y_score: np.ndarray, n_bins: int = 10) -> Dict[str, np.ndarray]:
    """分箱校准数据（用于绘制校准曲线）。"""
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score, dtype=float)
    bins = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(y_score, bins[1:-1]), 0, n_bins - 1)
    centers, observed, counts = [], [], []
    for b in range(n_bins):
        sel = idx == b
        if sel.sum() == 0:
            continue
        centers.append(float(y_score[sel].mean()))
        observed.append(float(y_true[sel].mean()))
        counts.append(int(sel.sum()))
    return {
        "predicted": np.array(centers),
        "observed": np.array(observed),
        "counts": np.array(counts),
    }


def hosmer_lemeshow(y_true: np.ndarray, y_prob: np.ndarray, groups: int = 10) -> Dict[str, float]:
    """Hosmer-Lemeshow 拟合优度检验。"""
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob, dtype=float)
    order = np.argsort(y_prob)
    splits = np.array_split(order, groups)
    chi2 = 0.0
    for g in splits:
        if g.size == 0:
            continue
        o1 = y_true[g].sum()
        o0 = g.size - o1
        e1 = y_prob[g].sum()
        e0 = g.size - e1
        if e1 > 0:
            chi2 += (o1 - e1) ** 2 / e1
        if e0 > 0:
            chi2 += (o0 - e0) ** 2 / e0
    df = max(groups - 2, 1)
    p = float(stats.chi2.sf(chi2, df))
    return {"chi2": float(chi2), "df": df, "p_value": p}


# ---------------------------------------------------------------------------
# 决策曲线分析
# ---------------------------------------------------------------------------


def decision_curve(
    y_true: np.ndarray,
    y_score: np.ndarray,
    thresholds: Optional[Sequence[float]] = None,
) -> Dict[str, np.ndarray]:
    """DCA：返回各阈值下模型净收益、全部干预净收益、不干预净收益。"""
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score, dtype=float)
    n = y_true.size
    prevalence = y_true.mean()
    if thresholds is None:
        thresholds = np.arange(0.01, 1.0, 0.01)
    th = np.asarray(thresholds, dtype=float)

    nb_model = np.zeros_like(th)
    for i, t in enumerate(th):
        pred = y_score >= t
        tp = float((pred & (y_true == 1)).sum())
        fp = float((pred & (y_true == 0)).sum())
        nb_model[i] = tp / n - fp / n * (t / (1 - t))

    nb_all = prevalence - (1 - prevalence) * (th / (1 - th))
    nb_none = np.zeros_like(th)
    return {"threshold": th, "model": nb_model, "treat_all": nb_all, "treat_none": nb_none}


# ---------------------------------------------------------------------------
# DeLong 检验
# ---------------------------------------------------------------------------


def _compute_midrank(x: np.ndarray) -> np.ndarray:
    j = np.argsort(x)
    z = x[j]
    n = len(x)
    t = np.zeros(n, dtype=float)
    i = 0
    while i < n:
        k = i
        while k < n and z[k] == z[i]:
            k += 1
        t[i:k] = 0.5 * (i + k - 1) + 1
        i = k
    out = np.empty(n, dtype=float)
    out[j] = t
    return out


def _fast_delong(preds: np.ndarray, labels: np.ndarray):
    """FastDeLong：preds 形状 (k, n)，labels 形状 (n,)。"""
    k, n = preds.shape
    pos = labels == 1
    neg = ~pos
    m, nn = int(pos.sum()), int(neg.sum())
    tx = np.empty((k, m))
    ty = np.empty((k, nn))
    tz = np.empty((k, n))
    for r in range(k):
        tx[r] = _compute_midrank(preds[r, pos])
        ty[r] = _compute_midrank(preds[r, neg])
        tz[r] = _compute_midrank(preds[r])
    aucs = tz[:, pos].sum(axis=1) / m / nn - (m + 1.0) / 2.0 / nn
    v01 = (tz[:, pos] - tx) / nn
    v10 = 1.0 - (tz[:, neg] - ty) / m
    sx = np.cov(v01) if k > 1 else np.array([[np.var(v01)]])
    sy = np.cov(v10) if k > 1 else np.array([[np.var(v10)]])
    return aucs, sx / m + sy / nn


def delong_test(
    y_true: np.ndarray,
    score_a: np.ndarray,
    score_b: np.ndarray,
) -> Dict[str, float]:
    """两条 ROC 曲线 AUC 差异的 DeLong 检验。"""
    y_true = np.asarray(y_true).astype(int)
    preds = np.vstack([np.asarray(score_a, float), np.asarray(score_b, float)])
    aucs, cov = _fast_delong(preds, y_true)
    diff = aucs[0] - aucs[1]
    var = cov[0, 0] + cov[1, 1] - 2 * cov[0, 1]
    z = diff / np.sqrt(var) if var > 0 else np.nan
    p = float(2 * stats.norm.sf(abs(z))) if np.isfinite(z) else np.nan
    return {
        "auc_a": float(aucs[0]), "auc_b": float(aucs[1]),
        "difference": float(diff), "z": float(z), "p_value": p,
    }


# ---------------------------------------------------------------------------
# NRI / IDI
# ---------------------------------------------------------------------------


def continuous_nri(
    y_true: np.ndarray,
    new_score: np.ndarray,
    old_score: np.ndarray,
) -> Dict[str, float]:
    """连续型净重分类改善（含 NRI+ / NRI- 分量）。"""
    y_true = np.asarray(y_true).astype(int)
    new = np.asarray(new_score, float)
    old = np.asarray(old_score, float)
    events = y_true == 1
    non = ~events

    up_e = float((new[events] > old[events]).mean()) if events.any() else np.nan
    down_e = float((new[events] < old[events]).mean()) if events.any() else np.nan
    up_n = float((new[non] > old[non]).mean()) if non.any() else np.nan
    down_n = float((new[non] < old[non]).mean()) if non.any() else np.nan

    nri_plus = up_e - down_e
    nri_minus = down_n - up_n
    total = nri_plus + nri_minus
    # 近似 z 检验：以两部分样本量加权
    se = np.sqrt(
        max(up_e + down_e, 1e-8) / max(events.sum(), 1) + max(up_n + down_n, 1e-8) / max(non.sum(), 1)
    )
    z = total / se if se > 0 else np.nan
    p = float(2 * stats.norm.sf(abs(z))) if np.isfinite(z) else np.nan
    return {
        "NRI": float(total), "NRI_plus": float(nri_plus), "NRI_minus": float(nri_minus),
        "z": float(z), "p_value": p,
    }


def idi(
    y_true: np.ndarray,
    new_score: np.ndarray,
    old_score: np.ndarray,
) -> Dict[str, float]:
    """综合判别改善指数 IDI。"""
    y_true = np.asarray(y_true).astype(int)
    new = np.asarray(new_score, float)
    old = np.asarray(old_score, float)
    events = y_true == 1
    non = ~events

    d_new = new[events].mean() - new[non].mean()
    d_old = old[events].mean() - old[non].mean()
    value = float(d_new - d_old)
    se = float(
        np.sqrt(
            new[events].var(ddof=1) / max(events.sum(), 1)
            + new[non].var(ddof=1) / max(non.sum(), 1)
            + old[events].var(ddof=1) / max(events.sum(), 1)
            + old[non].var(ddof=1) / max(non.sum(), 1)
        )
    )
    z = value / se if se > 0 else np.nan
    return {"IDI": value, "z": float(z), "p_value": float(2 * stats.norm.sf(abs(z))) if np.isfinite(z) else np.nan}


# ---------------------------------------------------------------------------
# 汇总
# ---------------------------------------------------------------------------


def full_report(
    y_true: np.ndarray,
    y_score: np.ndarray,
    threshold: float = 0.5,
    n_boot: int = 1000,
    hl_groups: int = 10,
) -> Dict[str, float]:
    """一次性输出全部基础指标（含 AUC 置信区间与 HL 检验）。"""
    out = classification_metrics(y_true, y_score, threshold=threshold)
    auc, lo, hi = bootstrap_auc_ci(y_true, y_score, n_boot=n_boot)
    out["AUC_lower"], out["AUC_upper"] = lo, hi
    out.update({f"HL_{k}": v for k, v in hosmer_lemeshow(y_true, y_score, groups=hl_groups).items()})
    return out


def roc_points(y_true: np.ndarray, y_score: np.ndarray) -> Tuple[np.ndarray, np.ndarray, float]:
    fpr, tpr, _ = roc_curve(np.asarray(y_true).astype(int), np.asarray(y_score, float))
    return fpr, tpr, float(roc_auc_score(y_true, y_score))
