"""数据读取与队列划分。

覆盖三类输入：
1. 临床/病理/随访汇总表（xlsx / csv）
2. 超声图像（jpg / png，二维）
3. 3D Slicer 分割掩膜（.nrrd）
   优先级：SimpleITK -> nrrd 库 -> 内置轻量 NRRD 解析器（支持 gzip/raw、
   uint8/uint16、二维与三维，足够读取 Slicer 导出的 Segment 掩膜）
"""

from __future__ import annotations

import gzip
import os
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# NRRD
# ---------------------------------------------------------------------------


def _read_nrrd_header(raw: bytes) -> Tuple[Dict[str, str], int]:
    """解析 NRRD ASCII 头，返回 (字段字典, 数据起始偏移)。"""
    lines: List[str] = []
    pos = 0
    if not raw.startswith(b"NRRD"):
        raise ValueError("不是合法的 NRRD 文件")
    while pos < len(raw):
        line_end = raw.find(b"\n", pos)
        if line_end == -1:
            raise ValueError("NRRD 头部不完整")
        line = raw[pos:line_end].decode("latin-1").strip()
        pos = line_end + 1
        if line == "":
            break
        if line.startswith("#"):
            continue
        lines.append(line)

    header: Dict[str, str] = {}
    for line in lines:
        if line.upper().startswith("NRRD"):
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        header[key.strip()] = value.strip()
    return header, pos


_NRRD_DTYPES = {
    "signed char": np.int8,
    "int8": np.int8,
    "int8_t": np.int8,
    "unsigned char": np.uint8,
    "uint8": np.uint8,
    "uint8_t": np.uint8,
    "short": np.int16,
    "short int": np.int16,
    "int16": np.int16,
    "int16_t": np.int16,
    "unsigned short": np.uint16,
    "ushort": np.uint16,
    "uint16": np.uint16,
    "uint16_t": np.uint16,
    "int": np.int32,
    "int32": np.int32,
    "int32_t": np.int32,
    "unsigned int": np.uint32,
    "uint32": np.uint32,
    "uint32_t": np.uint32,
    "float": np.float32,
    "float32": np.float32,
    "double": np.float64,
    "float64": np.float64,
}


def read_nrrd(path: str | Path) -> Tuple[np.ndarray, Dict[str, str]]:
    """读取 NRRD，返回 (数组, 头部字段)。

    数组按 NRRD 的坐标顺序返回，形状为 (x, y, z)（与 sizes 字段顺序一致），
    与 SimpleITK.GetArrayFromImage 的 (z, y, x) 不同，调用方按需转置。
    """
    raw = open(path, "rb").read()
    header, offset = _read_nrrd_header(raw)

    dtype = _NRRD_DTYPES.get(header.get("type", "").lower())
    if dtype is None:
        raise ValueError(f"不支持的 NRRD 数据类型: {header.get('type')}")

    sizes = [int(s) for s in header.get("sizes", "").split()]
    encoding = header.get("encoding", "raw").lower()
    payload = raw[offset:]

    if encoding == "gzip":
        payload = gzip.decompress(payload)
    elif encoding in ("raw", "txt"):
        pass
    elif encoding == "ascii":
        vals = np.array(payload.decode("latin-1").split(), dtype=np.float64)
        arr = vals.astype(dtype)
        return arr.reshape(sizes, order="F"), header
    else:
        raise ValueError(f"不支持的 NRRD 编码: {encoding}")

    arr = np.frombuffer(payload, dtype=np.dtype(dtype).newbyteorder("<"))
    expected = int(np.prod(sizes))
    if arr.size != expected:
        raise ValueError(f"NRRD 数据长度 {arr.size} 与 sizes {sizes} 不符")
    # NRRD 按 Fortran 顺序存储（第一维变化最快），必须用 order="F" 还原，
    # 否则二维掩膜会被打散成碎片（本数据集实测会被拆成 100+ 个连通域）。
    return arr.reshape(sizes, order="F"), header


def nrrd_to_2d_mask(path: str | Path) -> np.ndarray:
    """把分割 NRRD 转成二维掩膜 (H, W)，坐标约定为行=y、列=x。

    * 取第一个非空切片（二维超声只有一层）
    * 多标签掩膜保留标签值；二值掩膜返回 0/1
    """
    arr, _ = read_nrrd(path)
    if arr.ndim == 3:
        # sizes = (x, y, z) -> 转成 (z, y, x) 后取第一个切片
        arr = np.transpose(arr, (2, 1, 0))
        nonempty = [i for i in range(arr.shape[0]) if arr[i].max() > 0]
        if not nonempty:
            raise ValueError(f"掩膜为空: {path}")
        arr = arr[nonempty[0]]
    elif arr.ndim != 2:
        raise ValueError(f"不支持的掩膜维度: {arr.shape}")
    return arr.astype(np.float32)


def write_nrrd_binary(mask: np.ndarray, path: str | Path) -> None:
    """把二维标签图写成 NRRD（gzip 编码），便于回 3D Slicer 复核。"""
    arr = np.asarray(mask)
    if arr.ndim == 2:
        arr = arr[:, :, None]
    arr = arr.astype(np.uint8)
    sizes = list(arr.shape)          # (x, y, z) 顺序
    payload = np.asfortranarray(arr).tobytes(order="F")
    header = (
        "NRRD0004\n"
        "# 由论文代码包生成：嵌套生境标签图\n"
        "type: unsigned char\n"
        "dimension: 3\n"
        "space: left-posterior-superior\n"
        f"sizes: {sizes[0]} {sizes[1]} {sizes[2]}\n"
        "space directions: (1,0,0) (0,1,0) (0,0,1)\n"
        "kinds: domain domain domain\n"
        "encoding: gzip\n"
        "space origin: (0,0,0)\n\n"
    ).encode("latin-1")
    with open(path, "wb") as f:
        f.write(header)
        f.write(gzip.compress(payload))


# ---------------------------------------------------------------------------
# 超声图像
# ---------------------------------------------------------------------------


def read_ultrasound_image(path: str | Path) -> np.ndarray:
    """读取二维超声图像，返回 uint8 灰度 (H, W)。

    彩色多普勒图像同时包含彩色血流信息与灰阶背景；本项目对 Color 模态
    使用官方导出图像，保留其 RGB 通道的平均亮度作为灰度强度
    （与稿件「彩色多普勒模式纳入血流信号」的处理一致）。
    """
    from PIL import Image

    im = Image.open(path)
    if im.mode != "L":
        im = im.convert("L")
    return np.asarray(im, dtype=np.uint8)


# ---------------------------------------------------------------------------
# 临床表与队列
# ---------------------------------------------------------------------------


def read_clinical_table(path: str | Path, sheet: Optional[str] = None) -> pd.DataFrame:
    """读取临床汇总表（xlsx / xls / csv）。"""
    suffix = Path(path).suffix.lower()
    if suffix == ".csv":
        df = pd.read_csv(path)
    else:
        df = pd.read_excel(path, sheet_name=sheet or 0)
    df.columns = [str(c).strip() for c in df.columns]
    return df


def build_labels(
    df: pd.DataFrame,
    id_column: str,
    label_column: str,
    label_map: Dict[int, int],
    time_column: Optional[str] = None,
) -> pd.DataFrame:
    """构造建模用标签表：case_id / label / time。"""
    out = pd.DataFrame({"case_id": df[id_column].astype(int)})
    raw = df[label_column]
    if label_map:
        out["label"] = raw.map(lambda v: label_map.get(int(v), np.nan) if pd.notna(v) else np.nan)
    else:
        out["label"] = raw
    if time_column and time_column in df.columns:
        out["time"] = df[time_column]
    out = out.dropna(subset=["label"])
    out["label"] = out["label"].astype(int)
    return out


def split_cohorts(
    labels: pd.DataFrame,
    internal_test_size: float = 0.3,
    random_state: int = 42,
    stratify: bool = True,
    external_ids: Optional[Sequence[int]] = None,
) -> Dict[str, pd.DataFrame]:
    """按 7:3 划分训练/内部测试集，并返回外部验证集。"""
    from sklearn.model_selection import train_test_split

    if external_ids:
        ext_ids = set(int(i) for i in external_ids)
        internal = labels[~labels["case_id"].isin(ext_ids)].copy()
        external = labels[labels["case_id"].isin(ext_ids)].copy()
    else:
        internal = labels.copy()
        external = labels.iloc[0:0].copy()

    strat = internal["label"] if stratify else None
    train_idx, test_idx = train_test_split(
        np.arange(len(internal)),
        test_size=internal_test_size,
        random_state=random_state,
        stratify=strat,
    )
    return {
        "train": internal.iloc[train_idx].reset_index(drop=True),
        "test": internal.iloc[test_idx].reset_index(drop=True),
        "external": external.reset_index(drop=True),
    }


def discover_cases(image_root: str | Path, modalities: Sequence[str] = ("彩色", "黑白")) -> pd.DataFrame:
    """扫描影像目录，返回每个病例可用的模态文件路径。

    目录结构：
        <image_root>/<病例号>/<彩色|黑白>/images/<病例号>.jpg
        <image_root>/<病例号>/<彩色|黑白>/masks/<病例号>.nrrd
    """
    root = Path(image_root)
    records: List[Dict[str, object]] = []
    for case_dir in sorted([d for d in root.iterdir() if d.is_dir()], key=lambda d: _as_int(d.name)):
        cid = _as_int(case_dir.name)
        if cid is None:
            continue
        rec: Dict[str, object] = {"case_id": cid}
        for mod in modalities:
            rec[f"image_{mod}"] = ""
            rec[f"mask_{mod}"] = ""
            mod_dir = case_dir / mod
            if not mod_dir.exists():
                continue
            img_dir, mask_dir = mod_dir / "images", mod_dir / "masks"
            if img_dir.exists():
                for ext in (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"):
                    f = img_dir / f"{case_dir.name}{ext}"
                    if f.exists():
                        rec[f"image_{mod}"] = str(f)
                        break
            if mask_dir.exists():
                for ext in (".nrrd", ".nii", ".nii.gz", ".mha"):
                    f = mask_dir / f"{case_dir.name}{ext}"
                    if f.exists():
                        rec[f"mask_{mod}"] = str(f)
                        break
        records.append(rec)
    return pd.DataFrame.from_records(records)


def _as_int(name: str) -> Optional[int]:
    try:
        return int(str(name).strip())
    except (TypeError, ValueError):
        return None


def merge_case_paths(
    cohort: pd.DataFrame, cases: pd.DataFrame, image_root: str | Path
) -> pd.DataFrame:
    """把队列标签与影像路径合并；外部队列可用独立目录。"""
    merged = cohort.merge(cases, on="case_id", how="left")
    missing = merged["image_黑白"].isna() | (merged["image_黑白"] == "")
    if missing.any():
        merged.loc[missing, "image_黑白"] = ""
    return merged
