"""主流程：一键复现稿件全部分析步骤。

用法（在代码包根目录执行）：
    python run_pipeline.py --step all                     # 全流程
    python run_pipeline.py --step 1                       # 只做队列与基线表
    python run_pipeline.py --step 2 --limit 5             # 只对前 5 例提特征（调试）
    python run_pipeline.py --step 3 4 5 --backend lite    # 依次执行多个步骤

步骤编号：
    1  队列构建与基线表（Table 1）
    2  影像预处理、生境分割与特征提取
    3  特征筛选与影像组学标签
    4  9 种算法比较与最优基模型（Table S1–S5）
    5  临床-生境联合模型与模型比较（Fig. 3–5）
    6  免疫微环境探索分析（Fig. 6）
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from src import (  # noqa: E402
    combined,
    feature_selection,
    habitat,
    icc,
    immune_analysis,
    io_utils,
    metrics,
    models,
    plotting,
    radiomics_extraction,
)
from src import preprocess as prep  # noqa: E402
from src.config import get, load_config, set_seed  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("pipeline")

MODALITIES = {"Color": "彩色", "US": "黑白"}


# ---------------------------------------------------------------------------
# 通用
# ---------------------------------------------------------------------------


def _paths(cfg: dict) -> Dict[str, Path]:
    p = cfg["paths"]
    return {
        "features": Path(p["features_dir"]),
        "habitat": Path(p["habitat_dir"]),
        "tables": Path(p["tables_dir"]),
        "figures": Path(p["figures_dir"]),
    }


def _baseline_table(df: pd.DataFrame, continuous: List[str], categorical: List[str],
                    label_col: str = "label") -> pd.DataFrame:
    """Table 1：连续变量 median[IQR] + Mann-Whitney；分类变量 n(%) + χ²。"""
    rows = []
    g1 = df[label_col] == 1
    g0 = ~g1

    def fmt_iqr(series):
        s = series.dropna()
        return f"{s.median():.2f} [{s.quantile(0.25):.2f}-{s.quantile(0.75):.2f}]"

    for var in continuous:
        if var not in df.columns:
            continue
        a, b = df.loc[g1, var].dropna(), df.loc[g0, var].dropna()
        try:
            p = stats_mannwhitney(a, b)
        except Exception:
            p = np.nan
        rows.append({
            "Characteristic": f"{var}, median [IQR]",
            "Total": fmt_iqr(df[var]),
            "Non-Recurrence": fmt_iqr(df.loc[g0, var]),
            "Recurrence": fmt_iqr(df.loc[g1, var]),
            "P_value": p,
        })

    for var in categorical:
        if var not in df.columns:
            continue
        ct = pd.crosstab(df[var], df[label_col])
        try:
            from scipy import stats as st

            chi2, p, _, _ = st.chi2_contingency(ct.values)
        except Exception:
            p = np.nan
        rows.append({
            "Characteristic": f"{var}, n (%)",
            "Total": "", "Non-Recurrence": "", "Recurrence": "", "P_value": p,
        })
        for level in ct.index:
            n_all = int(ct.loc[level].sum())
            n0 = int(ct.loc[level].get(0, 0))
            n1 = int(ct.loc[level].get(1, 0))
            rows.append({
                "Characteristic": f"  {level}",
                "Total": f"{n_all} ({n_all / len(df) * 100:.1f}%)",
                "Non-Recurrence": f"{n0} ({n0 / max(g0.sum(), 1) * 100:.1f}%)",
                "Recurrence": f"{n1} ({n1 / max(g1.sum(), 1) * 100:.1f}%)",
                "P_value": "",
            })
    return pd.DataFrame(rows)


def stats_mannwhitney(a, b) -> float:
    from scipy import stats as st

    return float(st.mannwhitneyu(a, b, alternative="two-sided").pvalue)


# ---------------------------------------------------------------------------
# Step 1：队列
# ---------------------------------------------------------------------------


def step1_cohort(cfg: dict, limit: int = 0) -> pd.DataFrame:
    """构建训练/内部测试/外部验证三队列。

    注意：外部验证队列的病例号可能与内部队列重号（本数据集的 1..120 均为
    两种情况），因此外部队列的 case_id 统一加上 external_id_offset，
    避免与内部队列混淆；原始号保存在 source_id 列。
    """
    paths = _paths(cfg)
    c = cfg["cohort"]
    seed = int(cfg["project"]["random_seed"])

    # ---- 内部队列：临床表 -> 标签 ----
    clinical = io_utils.read_clinical_table(cfg["paths"]["clinical_table"], cfg["paths"].get("clinical_sheet"))
    clinical = clinical.rename(columns={c["id_column"]: "case_id"})
    labels = io_utils.build_labels(
        clinical, id_column="case_id", label_column=c["label_column"],
        label_map=c.get("label_map") or {}, time_column=c.get("time_column"),
    )

    # ---- 外部队列：临床表（可为同一表的另一工作表）+ 外部影像目录 ----
    ext_sheet = cfg["paths"].get("clinical_sheet_external")
    ext_clinical = None
    if ext_sheet:
        try:
            ext_clinical = io_utils.read_clinical_table(cfg["paths"]["clinical_table"], ext_sheet)
            ext_clinical = ext_clinical.rename(columns={c["id_column"]: "case_id"})
        except Exception as exc:  # noqa: BLE001
            logger.warning("读取外部验证表(%s)失败: %s", ext_sheet, exc)

    if ext_clinical is not None:
        ext_labels = io_utils.build_labels(
            ext_clinical, id_column="case_id", label_column=c["label_column"],
            label_map=c.get("label_map") or {}, time_column=c.get("time_column"),
        )
    else:
        ext_labels = pd.DataFrame(columns=["case_id", "label"])

    # ---- 7:3 划分内部队列 ----
    from sklearn.model_selection import train_test_split

    strat = labels["label"] if c.get("stratify", True) else None
    train_idx, test_idx = train_test_split(
        np.arange(len(labels)),
        test_size=float(c.get("internal_test_size", 0.3)),
        random_state=seed,
        stratify=strat,
    )
    cohorts = {
        "train": labels.iloc[train_idx].reset_index(drop=True),
        "test": labels.iloc[test_idx].reset_index(drop=True),
        "external": ext_labels.reset_index(drop=True),
    }

    # ---- 影像路径（内部与外部分别扫描）----
    internal_cases = io_utils.discover_cases(
        cfg["paths"]["image_root"], modalities=tuple(MODALITIES.values())
    )
    ext_cases = pd.DataFrame()
    if cfg["paths"].get("external_image_root") and Path(cfg["paths"]["external_image_root"]).exists():
        ext_cases = io_utils.discover_cases(
            cfg["paths"]["external_image_root"], modalities=tuple(MODALITIES.values())
        )

    merged: List[pd.DataFrame] = []
    for name, df in cohorts.items():
        if df.empty:
            continue
        df = df.copy()
        df["source_id"] = df["case_id"]
        if name == "external":
            if ext_cases.empty:
                logger.warning("外部队列缺少影像目录，跳过")
                continue
            offset = int(c.get("external_id_offset", 10000))
            df = df.merge(ext_cases, on="case_id", how="left")
            df["case_id"] = df["case_id"].astype(int) + offset
            # 临床变量
            if ext_clinical is not None:
                df = df.merge(ext_clinical.drop(columns=["label"], errors="ignore"),
                              left_on="source_id", right_on="case_id", how="left",
                              suffixes=("", "_clin"))
        else:
            df = df.merge(internal_cases, on="case_id", how="left")
            df = df.merge(clinical.drop(columns=["label"], errors="ignore"),
                          on="case_id", how="left", suffixes=("", "_clin"))
        df["cohort"] = name
        merged.append(df)

    cohort_df = pd.concat(merged, ignore_index=True, sort=False)
    if limit:
        cohort_df = pd.concat(
            [g.head(limit) for _, g in cohort_df.groupby("cohort")], ignore_index=True
        )

    cohort_df.to_csv(paths["tables"] / "cohort.csv", index=False, encoding="utf-8-sig")

    # 基线表（Table 1）
    t1 = _baseline_table(
        cohort_df,
        continuous=list(cfg["clinical"]["continuous"]),
        categorical=list(cfg["clinical"]["categorical"]),
    )
    t1.to_csv(paths["tables"] / "Table1_baseline.csv", index=False, encoding="utf-8-sig")

    logger.info(
        "队列完成：train=%d, test=%d, external=%d（共 %d 例，复发 %d 例）",
        (cohort_df["cohort"] == "train").sum(), (cohort_df["cohort"] == "test").sum(),
        (cohort_df["cohort"] == "external").sum(), len(cohort_df), int(cohort_df["label"].sum()),
    )
    return cohort_df


# ---------------------------------------------------------------------------
# Step 2：预处理 + 生境分割 + 特征提取
# ---------------------------------------------------------------------------


def _process_one_case(task: dict) -> dict:
    """单个（病例, 模态）的完整处理：预处理 -> 常规特征 -> 嵌套生境 -> 生境特征。

    独立成模块级函数以便多进程并行（Windows 下需要可 pickle 的任务）。
    """
    cfg = task["cfg"]
    case_id = task["case_id"]
    mod_name = task["modality"]
    result = {"case_id": case_id, "modality": mod_name, "ok": False}

    # ---- 断点续跑：已完成的（病例, 模态）直接从缓存读取 ----
    cache_path = Path(task["cache_dir"]) / f"{case_id}_{mod_name}.json"
    if task.get("resume", True) and cache_path.exists():
        try:
            with open(cache_path, "r", encoding="utf-8") as fh:
                cached = json.load(fh)
            cached.update({"case_id": case_id, "modality": mod_name, "cached": True})
            return cached
        except Exception:  # noqa: BLE001
            pass  # 缓存损坏则重新计算

    try:
        image = io_utils.read_ultrasound_image(task["image_path"])
        mask_raw = io_utils.nrrd_to_2d_mask(task["mask_path"])
        image_p, mask = prep.preprocess_image(image, mask_raw, cfg)
    except Exception as exc:  # noqa: BLE001
        result["error"] = f"预处理失败: {exc}"
        return result

    # --- 常规全肿瘤特征 ---
    conv = radiomics_extraction.extract_features(image_p, mask, cfg, backend=task["backend"])
    result["conv_row"] = {
        "case_id": case_id, "modality": mod_name,
        **{f"{mod_name}__{k}": v for k, v in conv.items()},
    }

    # --- 嵌套生境 ---
    try:
        seg = habitat.nested_habitat_segmentation(
            image_p, mask, cfg, random_state=int(cfg["project"]["random_seed"])
        )
    except Exception as exc:  # noqa: BLE001
        result["error"] = f"生境分割失败: {exc}"
        return result
    hmasks = habitat.habitat_masks(seg, min_pixels=int(get(cfg, "habitat.min_pixels", 30)))
    hab_feats = radiomics_extraction.extract_habitat_features(
        image_p, hmasks, cfg, backend=task["backend"], modality=f"Habitat_{mod_name}"
    )
    result["hab_row"] = {"case_id": case_id, "modality": mod_name,
                         "n_habitats": len(hmasks), **hab_feats}
    result["seg_row"] = habitat.habitat_summary(seg, case_id, mod_name)

    if task.get("save_masks"):
        out_dir = Path(task["habitat_dir"])
        np.save(out_dir / f"{case_id}_{mod_name}_level1.npy", seg["level1_labels"])
        np.save(out_dir / f"{case_id}_{mod_name}_level2.npy", seg["level2_labels"])
        try:
            io_utils.write_nrrd_binary(seg["level1_labels"],
                                       out_dir / f"{case_id}_{mod_name}_habitat.nrrd")
        except Exception:  # noqa: BLE001
            pass

    result["preview"] = (image_p, seg["level1_labels"], seg["level2_labels"])
    result["ok"] = True
    result["n_conv"] = len(conv)
    result["n_habitats"] = len(hmasks)

    # 写入缓存（供断点续跑；不含大数组）
    try:
        keep = {k: v for k, v in result.items()
                if k in ("ok", "conv_row", "hab_row", "seg_row", "n_conv", "n_habitats", "error")}
        with open(cache_path, "w", encoding="utf-8") as fh:
            json.dump(keep, fh, ensure_ascii=False)
    except Exception:  # noqa: BLE001
        pass
    return result


def step2_features(cfg: dict, cohort_df: pd.DataFrame, backend: str = "auto",
                   save_masks: bool = True, plot_examples: int = 2,
                   workers: int = 0, resume: bool = True) -> None:
    paths = _paths(cfg)
    (paths["features"] / "cache").mkdir(parents=True, exist_ok=True)
    backend = radiomics_extraction.resolve_backend(backend)
    logger.info("特征提取后端: %s", backend)

    tasks: List[dict] = []
    for _, row in cohort_df.iterrows():
        case_id = int(row["case_id"])
        for mod_name, mod_cn in MODALITIES.items():
            img_path = row.get(f"image_{mod_cn}", "")
            mask_path = row.get(f"mask_{mod_cn}", "")
            if not img_path or not mask_path or pd.isna(img_path) or pd.isna(mask_path):
                continue
            tasks.append({
                "cfg": cfg, "case_id": case_id, "modality": mod_name,
                "image_path": str(img_path), "mask_path": str(mask_path),
                "backend": backend, "save_masks": save_masks,
                "habitat_dir": str(paths["habitat"]),
                "cache_dir": str(paths["features"] / "cache"),
                "resume": bool(resume),
            })

    if not tasks:
        logger.warning("没有可处理的病例（检查影像路径）")
        return

    if workers <= 0:
        workers = max(1, (os.cpu_count() or 4) - 1)
    workers = min(workers, len(tasks))
    logger.info("共 %d 个（病例×模态）任务，使用 %d 进程并行", len(tasks), workers)

    conv_rows: List[dict] = []
    hab_rows: List[dict] = []
    seg_rows: List[dict] = []
    plotted = 0
    t0 = time.time()

    def _consume(res: dict) -> None:
        nonlocal plotted
        if res.get("conv_row"):
            conv_rows.append(res["conv_row"])
        if not res.get("ok"):
            logger.warning("病例 %s / %s %s", res["case_id"], res["modality"],
                           res.get("error", "未知错误"))
            return
        hab_rows.append(res["hab_row"])
        seg_rows.append(res["seg_row"])
        if plotted < plot_examples and res.get("preview"):
            img, l1, l2 = res["preview"]
            plotting.plot_habitat_map(
                img, l1, l2,
                paths["figures"] / f"habitat_example_{res['case_id']}_{res['modality']}",
                case_id=f"{res['case_id']}-{res['modality']}",
            )
            plotted += 1
        logger.info("病例 %s / %s 完成：常规 %d 特征，生境 %d 区",
                    res["case_id"], res["modality"], res.get("n_conv", 0),
                    res["hab_row"]["n_habitats"])

    if workers == 1:
        for task in tasks:
            _consume(_process_one_case(task))
    else:
        from concurrent.futures import ProcessPoolExecutor, as_completed

        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(_process_one_case, t) for t in tasks]
            for fut in as_completed(futures):
                _consume(fut.result())

    logger.info("特征提取总耗时 %.1f 分钟", (time.time() - t0) / 60.0)

    conv_df = pd.DataFrame(conv_rows)
    hab_df = pd.DataFrame(hab_rows)
    seg_df = pd.DataFrame(seg_rows)
    conv_df.to_csv(paths["features"] / "features_conventional.csv", index=False, encoding="utf-8-sig")
    hab_df.to_csv(paths["features"] / "features_habitat.csv", index=False, encoding="utf-8-sig")
    seg_df.to_csv(paths["features"] / "habitat_segmentation_summary.csv", index=False, encoding="utf-8-sig")
    logger.info("特征落盘：%d 例次常规特征，%d 例次生境特征", len(conv_df), len(hab_df))


# ---------------------------------------------------------------------------
# 特征表拼装
# ---------------------------------------------------------------------------


def _pivot_modality(df: pd.DataFrame, modality: str, prefix: str) -> pd.DataFrame:
    """把长表（每个病例多行模态）转为宽表，特征列加模态前缀。"""
    sub = df[df["modality"] == modality].drop(columns=["modality"], errors="ignore")
    if sub.empty:
        return pd.DataFrame()
    feat_cols = [c for c in sub.columns if c != "case_id"]
    sub = sub.rename(columns={c: f"{prefix}__{c}" if not c.startswith(prefix) else c for c in feat_cols})
    return sub.groupby("case_id").mean(numeric_only=True).reset_index()


def load_feature_tables(cfg: dict) -> Dict[str, pd.DataFrame]:
    """读取 Step 2 的结果，构造 4 个特征集宽表：Color / US / Habitat_Color / Habitat_US。"""
    paths = _paths(cfg)
    conv = pd.read_csv(paths["features"] / "features_conventional.csv")
    hab = pd.read_csv(paths["features"] / "features_habitat.csv")

    sets: Dict[str, pd.DataFrame] = {}
    for mod in MODALITIES:
        sets[mod] = _pivot_modality(conv, mod, mod)
        sets[f"Habitat_{mod}"] = _pivot_modality(hab, mod, f"Habitat_{mod}")
    return {k: v for k, v in sets.items() if not v.empty}


def _attach_label(features: pd.DataFrame, cohort_df: pd.DataFrame) -> pd.DataFrame:
    return features.merge(cohort_df[["case_id", "label", "cohort"]], on="case_id", how="inner")


# ---------------------------------------------------------------------------
# Step 3：特征筛选 + 标签
# ---------------------------------------------------------------------------


def step3_selection(cfg: dict, cohort_df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    paths = _paths(cfg)
    sets = load_feature_tables(cfg)
    labels_out = cohort_df[["case_id", "label", "cohort"]].copy()

    for name, feats in sets.items():
        data = _attach_label(feats, cohort_df)
        train = data[data["cohort"] == "train"]
        if train.empty or train["label"].nunique() < 2:
            logger.warning("%s 训练集为空或只有一个类别，跳过", name)
            continue
        X_train = train.drop(columns=["case_id", "label", "cohort"])
        # 去掉常数/全缺失列
        X_train = X_train.loc[:, X_train.notna().all() & (X_train.std() > 0)]
        if X_train.shape[1] < 3:
            logger.warning("%s 有效特征过少(%d)，跳过", name, X_train.shape[1])
            continue

        logger.info("[%s] 训练集 %d 例 / %d 特征", name, len(X_train), X_train.shape[1])
        sel = feature_selection.fit_selector(X_train, train["label"].values, cfg)
        sel.tables["univariate"].to_csv(
            paths["tables"] / f"{name}_univariate_test.csv", encoding="utf-8-sig"
        )
        sel.summary().to_csv(paths["tables"] / f"{name}_selected_features.csv", encoding="utf-8-sig")
        sel.tables["lasso_path"].to_csv(paths["tables"] / f"{name}_lasso_cv.csv", index=False,
                                        encoding="utf-8-sig")
        plotting.plot_lasso_cv(sel.tables["lasso_path"], paths["figures"] / f"{name}_feature_mse")
        plotting.plot_lasso_coefficients(sel, paths["figures"] / f"{name}_feature_weights")
        plotting.plot_correlation_heatmap(
            feature_selection.apply_scaler(sel.scaler, X_train)[sel.feature_names],
            paths["figures"] / f"{name}_correlation_heatmap", title=name,
        )
        plotting.plot_feature_importance(
            pd.Series(sel.lasso_coef, index=sel.feature_names),
            paths["figures"] / f"{name}_feature_importance", title=f"{name} LASSO coefficients",
        )

        # 三个队列的标签
        label_vals = []
        for cohort_name, grp in data.groupby("cohort"):
            X = grp.drop(columns=["case_id", "label", "cohort"])
            X = X.reindex(columns=X_train.columns)
            lab = sel.label(X.fillna(X_train.median()))
            label_vals.append(pd.DataFrame({"case_id": grp["case_id"].values,
                                            "cohort": cohort_name, f"{name}_label": lab}))
        labels_out = labels_out.merge(
            pd.concat(label_vals, ignore_index=True), on=["case_id", "cohort"], how="left"
        )

        # 保存保留特征的特征值（供后续 9 种算法使用）
        keep_df = data[["case_id", "label", "cohort"]].copy()
        for cohort_name, grp in data.groupby("cohort"):
            X = grp.drop(columns=["case_id", "label", "cohort"]).reindex(columns=X_train.columns)
            Z = sel.transform(X.fillna(X_train.median()))
            keep_df.loc[grp.index, sel.feature_names] = Z.values
        keep_df.to_csv(paths["features"] / f"selected_{name}.csv", index=False, encoding="utf-8-sig")

    labels_out.to_csv(paths["tables"] / "radiomics_labels.csv", index=False, encoding="utf-8-sig")
    logger.info("影像组学标签列：%s", [c for c in labels_out.columns if c.endswith("_label")])
    return {"sets": sets, "labels": labels_out}


# ---------------------------------------------------------------------------
# Step 4：9 种算法比较
# ---------------------------------------------------------------------------


def _cohort_splits(data: pd.DataFrame, feature_cols: List[str]):
    out = {}
    for name in ("train", "test", "external"):
        grp = data[data["cohort"] == name]
        if grp.empty:
            out[name] = (None, None)
            continue
        out[name] = (grp[feature_cols].astype(float), grp["label"].astype(int).values)
    return out


def _load_radiomics_labels(paths: dict) -> pd.DataFrame:
    """读取 Step 3 的标签表，只保留 case_id / cohort / *_label 列，避免与队列表的 label 重名。"""
    labels_df = pd.read_csv(paths["tables"] / "radiomics_labels.csv")
    keep = ["case_id", "cohort"] + [c for c in labels_df.columns if c.endswith("_label")]
    return labels_df[keep]


def step4_models(cfg: dict, cohort_df: pd.DataFrame, fast: bool = False) -> pd.DataFrame:
    paths = _paths(cfg)
    labels_df = _load_radiomics_labels(paths)
    data_all = cohort_df.merge(labels_df, on=["case_id", "cohort"], how="left")

    # 临床特征集
    clinical_vars = [v for v in cfg["clinical"]["continuous"] + cfg["clinical"]["categorical"]
                     if v in data_all.columns]
    all_tables: List[pd.DataFrame] = []
    best_models: Dict[str, models.TrainedModel] = {}
    set_models: Dict[str, Dict[str, models.TrainedModel]] = {}
    set_data: Dict[str, pd.DataFrame] = {}

    jobs: Dict[str, List[str]] = {}
    if clinical_vars:
        jobs["Clinic"] = clinical_vars
    for name in ("Color", "US", "Habitat_Color", "Habitat_US"):
        sel_csv = paths["features"] / f"selected_{name}.csv"
        if sel_csv.exists():
            cols = [c for c in pd.read_csv(sel_csv, nrows=1).columns
                    if c not in ("case_id", "label", "cohort")]
            if cols:
                jobs[name] = cols

    algorithms = cfg["models"]["candidates"]
    if fast:
        algorithms = ["LR", "SVM", "RandomForest", "ExtraTrees"]

    for set_name, cols in jobs.items():
        # 影像组学特征集的特征值保存在 selected_<set>.csv，需并入宽表
        if set_name == "Clinic":
            data = data_all
        else:
            sel_df = pd.read_csv(paths["features"] / f"selected_{set_name}.csv")
            sel_df = sel_df.drop(columns=["label"], errors="ignore")
            data = data_all.merge(sel_df, on=["case_id", "cohort"], how="left")
        data = data.dropna(subset=cols + ["label"])
        set_data[set_name] = data
        cohorts = _cohort_splits(data, cols)
        if cohorts["train"][0] is None or len(np.unique(cohorts["train"][1])) < 2:
            logger.warning("%s 训练数据不足，跳过", set_name)
            continue
        logger.info("[%s] 开始比较 %d 种算法（%d 特征，%d 例）",
                    set_name, len(algorithms), len(cols), len(cohorts["train"][1]))
        table, models_dict = models.compare_algorithms(
            cohorts["train"][0], cohorts["train"][1],
            {k: v for k, v in cohorts.items() if v[0] is not None},
            cfg, feature_set=set_name, algorithms=algorithms,
        )
        all_tables.append(table)
        set_models[set_name] = models_dict
        if not table.empty:
            best_name, best_tm = models.select_best_model(table, models_dict)
            best_models[set_name] = best_tm
            logger.info("[%s] 最优基模型: %s", set_name, best_name)
            table["is_best"] = (table["model"] == best_name)

            # 保存特征重要性（树模型）
            est = best_tm.final_estimator
            if hasattr(est, "feature_importances_"):
                plotting.plot_feature_importance(
                    pd.Series(est.feature_importances_, index=cols),
                    paths["figures"] / f"{set_name}_best_model_feature_importance",
                    title=f"{set_name} / {best_name}",
                )
            # SHAP
            if cfg.get("shap", {}).get("enabled", True):
                from src import shap_explain

                sv = shap_explain.shap_values(best_tm.estimator, cohorts["train"][0])
                if sv is not None:
                    shap_explain.shap_summary(
                        sv, cohorts["train"][0],
                        paths["figures"] / f"{set_name}_shap",
                        top_n=int(cfg["shap"].get("top_n_features", 20)),
                    )
                    shap_explain.shap_importance_table(sv, cohorts["train"][0]).to_csv(
                        paths["tables"] / f"{set_name}_shap_importance.csv", index=False,
                        encoding="utf-8-sig",
                    )

    if all_tables:
        table = pd.concat(all_tables, ignore_index=True)
        table.to_csv(paths["tables"] / "model_comparison_all_feature_sets.csv", index=False,
                     encoding="utf-8-sig")
        # 三个队列 ROC 图（复用上面已调参并拟合的各算法模型，不再重训）
        for set_name, cols in jobs.items():
            if set_name not in set_models or set_name not in set_data:
                continue
            data = set_data[set_name]
            for cohort_name in ("train", "test", "external"):
                grp = data[data["cohort"] == cohort_name]
                if grp.empty:
                    continue
                curves = {
                    m: (grp["label"].astype(int).values, tm.predict_proba(grp[cols].astype(float)))
                    for m, tm in set_models[set_name].items()
                }
                if curves:
                    plotting.plot_roc(curves, paths["figures"] / f"{set_name}_roc_{cohort_name}",
                                      title=f"{set_name} · {cohort_name}")
    return pd.concat(all_tables, ignore_index=True) if all_tables else pd.DataFrame()


# ---------------------------------------------------------------------------
# Step 5：联合模型
# ---------------------------------------------------------------------------


def step5_combined(cfg: dict, cohort_df: pd.DataFrame) -> Dict[str, object]:
    paths = _paths(cfg)
    labels_df = _load_radiomics_labels(paths)
    data = cohort_df.merge(labels_df, on=["case_id", "cohort"], how="left")

    clinic_vars = list(cfg["clinical"]["independent_risk_factors"])
    clinic_vars = [v for v in clinic_vars if v in data.columns]
    label_cols = {k: [c] for k, c in {
        "color": "Color_label", "us": "US_label",
        "habitat_color": "Habitat_Color_label", "habitat_us": "Habitat_US_label",
    }.items() if c in data.columns}

    state = {"clinic": clinic_vars, **label_cols}
    cand = combined.candidate_combined_sets(clinic_vars, state)

    # 联合模型涉及的全部变量（临床 + 各影像组学标签），缺失即剔除该例
    model_vars = sorted({v for feats in cand.values() for v in feats if v in data.columns})
    data = data.dropna(subset=model_vars + ["label"])
    if data[data["cohort"] == "train"]["label"].nunique() < 2:
        logger.warning("联合模型训练集不足，跳过 Step 5")
        return {"combined": {}, "table": pd.DataFrame(), "data": data}

    train = data[data["cohort"] == "train"]
    cm_all = combined.fit_all_combined(train, train["label"].values, cand)

    rows: List[dict] = []
    probs: Dict[str, Dict[str, np.ndarray]] = {}
    for name, cm in cm_all.items():
        for cohort_name in ("train", "test", "external"):
            grp = data[data["cohort"] == cohort_name].dropna(subset=clinic_vars)
            if grp.empty:
                continue
            p = cm.predict_proba(grp)
            m = metrics.full_report(grp["label"].values, p,
                                    n_boot=int(cfg["evaluation"].get("bootstrap_n", 1000)),
                                    hl_groups=int(cfg["evaluation"].get("hosmer_lemeshow_groups", 10)))
            rows.append({"model": name, "cohort": cohort_name, **m, "n": len(grp)})
            probs.setdefault(cohort_name, {})[name] = (grp["label"].values, p)

    combined_table = pd.DataFrame(rows)
    combined_table.to_csv(paths["tables"] / "combined_model_performance.csv", index=False,
                          encoding="utf-8-sig")

    # 与各单一模型的 DeLong / NRI / IDI 比较（以最好的联合模型为基准）
    if not combined_table.empty and "Combined" in cm_all:
        ref = "Combined"
        comp_rows = []
        for cohort_name in ("train", "test", "external"):
            grp = data[data["cohort"] == cohort_name].dropna(subset=clinic_vars)
            if grp.empty:
                continue
            y = grp["label"].values
            p_ref = cm_all[ref].predict_proba(grp)
            for other, cm in cm_all.items():
                if other == ref:
                    continue
                p_oth = cm.predict_proba(grp)
                d = metrics.delong_test(y, p_ref, p_oth)
                nri = metrics.continuous_nri(y, p_ref, p_oth)
                idi = metrics.idi(y, p_ref, p_oth)
                comp_rows.append({"reference": other, "cohort": cohort_name,
                                  "delong_p": d["p_value"], "auc_ref": d["auc_a"], "auc_other": d["auc_b"],
                                  "NRI": nri["NRI"], "NRI_p": nri["p_value"],
                                  "IDI": idi["IDI"], "IDI_p": idi["p_value"]})
        comp = pd.DataFrame(comp_rows)
        comp.to_csv(paths["tables"] / "model_comparison_delong_nri_idi.csv", index=False,
                    encoding="utf-8-sig")
        plot_df = pd.concat([
            comp.assign(metric="DeLong AUC difference", value=comp["auc_ref"] - comp["auc_other"],
                        p_value=comp["delong_p"])[["reference", "cohort", "metric", "value", "p_value"]],
            comp.assign(metric="NRI", value=comp["NRI"], p_value=comp["NRI_p"])[
                ["reference", "cohort", "metric", "value", "p_value"]],
            comp.assign(metric="IDI", value=comp["IDI"], p_value=comp["IDI_p"])[
                ["reference", "cohort", "metric", "value", "p_value"]],
        ])
        plotting.plot_comparison_bars(plot_df, paths["figures"] / "model_comparison_bars")

    # 图 4：ROC / 校准 / DCA
    for cohort_name, curves in probs.items():
        plotting.plot_roc(curves, paths["figures"] / f"combined_roc_{cohort_name}",
                          title=f"Combined model · {cohort_name}")
        plotting.plot_calibration(curves,
                                  paths["figures"] / f"combined_calibration_{cohort_name}",
                                  title=f"Calibration · {cohort_name}")
        plotting.plot_dca(curves,
                          paths["figures"] / f"combined_dca_{cohort_name}",
                          title=f"Decision curve · {cohort_name}")

    # 列线图（Fig.3）
    if "Combined" in cm_all:
        comps = combined.nomogram_components(cm_all["Combined"], train)
        plotting.plot_nomogram(comps, paths["figures"] / "nomogram_combined")

    # 单因素/多因素逻辑回归（Table 2）
    clinical_all = data.dropna(subset=clinic_vars + ["label"])
    variables = [v for v in cfg["clinical"]["continuous"] + cfg["clinical"]["categorical"]
                 if v in clinical_all.columns]
    try:
        uni = models.univariate_logistic(clinical_all, "label", variables)
        multi, kept = models.multivariate_logistic(
            clinical_all, "label", variables,
            method=cfg["clinical"].get("multivariate_method", "backward"),
        )
        uni.to_csv(paths["tables"] / "Table2_univariate.csv", encoding="utf-8-sig")
        multi.to_csv(paths["tables"] / "Table2_multivariate.csv", encoding="utf-8-sig")
        logger.info("多因素保留变量：%s", kept)
    except Exception as exc:  # noqa: BLE001
        logger.warning("逻辑回归失败: %s", exc)

    return {"combined": cm_all, "table": combined_table, "data": data}


# ---------------------------------------------------------------------------
# Step 6：免疫
# ---------------------------------------------------------------------------


def step6_immune(cfg: dict) -> Optional[Dict[str, object]]:
    table = cfg["paths"].get("immune_table")
    if not table or not Path(table).exists():
        logger.warning("未配置免疫组化表（paths.immune_table），跳过免疫分析")
        return None
    paths = _paths(cfg)
    res = immune_analysis.run_immune_analysis(
        table, cfg, paths["tables"], paths["figures"],
    )
    logger.info("免疫分析完成：AUC=%.3f", res["auc"]["AUC"])
    return res


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------


def main() -> None:
    ap = argparse.ArgumentParser(description="卵巢癌嵌套生境影像组学 —— 主流程")
    ap.add_argument("--step", nargs="+", default=["all"],
                    help="1..6 或 all")
    ap.add_argument("--config", default=None)
    ap.add_argument("--backend", default="auto", choices=["auto", "pyradiomics", "lite"])
    ap.add_argument("--limit", type=int, default=0, help="每队列最多处理例数（调试用）")
    ap.add_argument("--fast", action="store_true", help="精简网格与算法数量，加快调试")
    ap.add_argument("--workers", type=int, default=0,
                    help="Step 2 并行进程数；0 表示自动（CPU 核数-1），1 表示串行")
    ap.add_argument("--no-resume", action="store_true",
                    help="Step 2 忽略缓存，强制重新计算所有病例")
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(int(cfg["project"]["random_seed"]))
    plotting.setup_style()

    paths = _paths(cfg)
    cohort_csv = paths["tables"] / "cohort.csv"
    cohorts = pd.read_csv(cohort_csv) if cohort_csv.exists() else None

    steps = args.step
    if "all" in steps:
        steps = ["1", "2", "3", "4", "5", "6"]

    for s in steps:
        if s == "1":
            cohorts = step1_cohort(cfg, limit=args.limit)
        elif s == "2":
            if cohorts is None:
                cohorts = step1_cohort(cfg, limit=args.limit)
            step2_features(cfg, cohorts, backend=args.backend, plot_examples=2,
                           workers=args.workers or int(get(cfg, "runtime.workers", 0) or 0),
                           resume=not args.no_resume)
        elif s == "3":
            if cohorts is None:
                cohorts = pd.read_csv(cohort_csv)
            step3_selection(cfg, cohorts)
        elif s == "4":
            if cohorts is None:
                cohorts = pd.read_csv(cohort_csv)
            step4_models(cfg, cohorts, fast=args.fast)
        elif s == "5":
            if cohorts is None:
                cohorts = pd.read_csv(cohort_csv)
            step5_combined(cfg, cohorts)
        elif s == "6":
            step6_immune(cfg)
        else:
            logger.warning("未知步骤：%s", s)


if __name__ == "__main__":
    main()
