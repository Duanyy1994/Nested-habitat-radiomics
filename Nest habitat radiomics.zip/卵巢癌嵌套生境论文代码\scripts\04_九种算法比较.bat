@echo off
chcp 65001 >nul
cd /d "%~dp0.."
python run_pipeline.py --step 4
pause
