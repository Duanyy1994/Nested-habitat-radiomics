"""配置读取与路径解析。"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

import yaml

PACKAGE_ROOT = Path(__file__).resolve().parent.parent


def load_config(config_path: str | Path | None = None) -> Dict[str, Any]:
    """读取 config.yaml，并把所有相对路径解析为基于代码包根目录的绝对路径。"""
    path = Path(config_path) if config_path else PACKAGE_ROOT / "config.yaml"
    with open(path, "r", encoding="utf-8") as f:
        cfg: Dict[str, Any] = yaml.safe_load(f)

    cfg["_config_path"] = str(path)
    cfg["_root"] = str(PACKAGE_ROOT)

    # 输出目录：相对路径 -> 代码包内绝对路径
    paths = cfg.setdefault("paths", {})
    for key in ("outputs", "features_dir", "habitat_dir", "tables_dir", "figures_dir"):
        if key in paths and paths[key] and not os.path.isabs(str(paths[key])):
            paths[key] = str(PACKAGE_ROOT / paths[key])

    # 参数文件：相对路径 -> 代码包内绝对路径
    rad = cfg.setdefault("radiomics", {})
    if rad.get("params_file") and not os.path.isabs(str(rad["params_file"])):
        rad["params_file"] = str(PACKAGE_ROOT / rad["params_file"])

    for key in ("outputs", "features_dir", "habitat_dir", "tables_dir", "figures_dir"):
        if paths.get(key):
            os.makedirs(paths[key], exist_ok=True)

    return cfg


def get(cfg: Dict[str, Any], dotted: str, default: Any = None) -> Any:
    """按点号路径读取配置，例如 get(cfg, 'habitat.window_size', 5)。"""
    cur: Any = cfg
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


def set_seed(seed: int) -> None:
    """统一随机种子，保证划分、聚类与建模可复现。"""
    import random

    import numpy as np

    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
