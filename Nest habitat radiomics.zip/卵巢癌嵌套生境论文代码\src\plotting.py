"""绘图：稿件 Fig.1–Fig.6 与补充材料图的统一风格输出。"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams

from . import metrics


def setup_style(font: str = "Microsoft YaHei") -> None:
    """统一绘图风格；中文环境优先使用系统中文字体，缺失时回退 DejaVu Sans。"""
    rcParams.update({
        "figure.dpi": 120,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "font.family": font,
        "font.size": 9,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "legend.frameon": False,
        "axes.grid": False,
        "axes.unicode_minus": False,
    })
    rcParams["font.sans-serif"] = [font, "SimHei", "DejaVu Sans"]


def _save(fig, path: str | Path, formats: Sequence[str] = ("png", "svg")) -> List[str]:
    base = Path(path)
    base.parent.mkdir(parents=True, exist_ok=True)
    saved = []
    for fmt in formats:
        out = base.with_suffix(f".{fmt}")
        fig.savefig(out, format=fmt)
        saved.append(str(out))
    plt.close(fig)
    return saved


# ---------------------------------------------------------------------------
# ROC
# ---------------------------------------------------------------------------


def plot_roc(
    curves: Dict[str, Tuple[np.ndarray, np.ndarray]],
    path: str | Path,
    title: str = "",
    colors: Optional[Sequence[str]] = None,
    diagonal: bool = True,
) -> List[str]:
    """curves: {图例名: (y_true, y_score)}。"""
    fig, ax = plt.subplots(figsize=(4.2, 4.0))
    default_colors = plt.cm.tab10(np.linspace(0, 1, max(len(curves), 1)))
    for i, (label, (y, s)) in enumerate(curves.items()):
        fpr, tpr, auc = metrics.roc_points(y, s)
        ax.plot(fpr, tpr, lw=1.6,
                color=(colors[i] if colors else default_colors[i]),
                label=f"{label} (AUC = {auc:.3f})")
    if diagonal:
        ax.plot([0, 1], [0, 1], ls="--", lw=0.8, color="grey")
    ax.set_xlabel("1 - Specificity")
    ax.set_ylabel("Sensitivity")
    ax.set_xlim(-0.02, 1.02)
    ax.set_ylim(-0.02, 1.02)
    ax.set_aspect("equal")
    if title:
        ax.set_title(title, fontsize=10)
    ax.legend(loc="lower right", fontsize=7)
    return _save(fig, path)


# ---------------------------------------------------------------------------
# 校准曲线
# ---------------------------------------------------------------------------


def plot_calibration(
    curves: Dict[str, Tuple[np.ndarray, np.ndarray]],
    path: str | Path,
    title: str = "",
    n_bins: int = 10,
) -> List[str]:
    fig, ax = plt.subplots(figsize=(4.0, 4.0))
    ax.plot([0, 1], [0, 1], ls="--", lw=0.8, color="grey", label="Ideal")
    default_colors = plt.cm.tab10(np.linspace(0, 1, max(len(curves), 1)))
    for i, (label, (y, s)) in enumerate(curves.items()):
        data = metrics.calibration_data(y, s, n_bins=n_bins)
        ax.plot(data["predicted"], data["observed"], marker="o", ms=3, lw=1.4,
                color=default_colors[i], label=label)
    ax.set_xlabel("Predicted probability")
    ax.set_ylabel("Observed probability")
    ax.set_xlim(-0.02, 1.02)
    ax.set_ylim(-0.02, 1.02)
    if title:
        ax.set_title(title, fontsize=10)
    ax.legend(fontsize=7)
    return _save(fig, path)


# ---------------------------------------------------------------------------
# 决策曲线
# ---------------------------------------------------------------------------


def plot_dca(
    curves: Dict[str, Tuple[np.ndarray, np.ndarray]],
    path: str | Path,
    title: str = "",
    thresholds: Sequence[float] = tuple(np.arange(0.01, 0.99, 0.01)),
    ylim: Tuple[float, float] = (-0.05, 0.45),
) -> List[str]:
    fig, ax = plt.subplots(figsize=(4.2, 4.0))
    default_colors = plt.cm.tab10(np.linspace(0, 1, max(len(curves), 1)))
    for i, (label, (y, s)) in enumerate(curves.items()):
        d = metrics.decision_curve(y, s, thresholds=thresholds)
        ax.plot(d["threshold"], d["model"], lw=1.5, color=default_colors[i], label=label)
    # treat-all / treat-none 参考线
    any_y, any_s = next(iter(curves.values()))
    d_any = metrics.decision_curve(any_y, any_s, thresholds=thresholds)
    ax.plot(d_any["threshold"], d_any["treat_all"], ls="--", lw=0.9, color="grey", label="Treat all")
    ax.plot(d_any["threshold"], d_any["treat_none"], ls=":", lw=0.9, color="black", label="Treat none")
    ax.set_xlabel("Threshold probability")
    ax.set_ylabel("Net benefit")
    ax.set_xlim(0, 1)
    ax.set_ylim(*ylim)
    if title:
        ax.set_title(title, fontsize=10)
    ax.legend(fontsize=7, loc="upper right")
    return _save(fig, path)


# ---------------------------------------------------------------------------
# 特征相关性与重要性
# ---------------------------------------------------------------------------


def plot_correlation_heatmap(
    X: pd.DataFrame,
    path: str | Path,
    max_features: int = 40,
    title: str = "",
) -> List[str]:
    """相关性热图（纯 matplotlib 实现，不依赖 seaborn）。"""
    feats = list(X.columns)[:max_features]
    corr = X[feats].corr().values
    fig, ax = plt.subplots(figsize=(max(4.5, len(feats) * 0.22), max(4.0, len(feats) * 0.20)))
    im = ax.imshow(corr, cmap="RdBu_r", vmin=-1, vmax=1, aspect="equal")
    cbar = fig.colorbar(im, ax=ax, shrink=0.7)
    cbar.set_label("Pearson r", fontsize=7)
    ax.set_xticks(range(len(feats)))
    ax.set_yticks(range(len(feats)))
    ax.set_xticklabels([_shorten(f, 18) for f in feats], rotation=90, fontsize=5)
    ax.set_yticklabels([_shorten(f, 18) for f in feats], fontsize=5)
    if title:
        ax.set_title(title, fontsize=10)
    return _save(fig, path)


def plot_feature_importance(
    series: pd.Series,
    path: str | Path,
    top_n: int = 25,
    title: str = "Feature importance",
) -> List[str]:
    s = series.abs().sort_values(ascending=False).head(top_n)[::-1]
    fig, ax = plt.subplots(figsize=(4.6, max(2.5, len(s) * 0.18)))
    colors = ["#c0392b" if v > 0 else "#2e86c1" for v in series.reindex(s.index).values]
    ax.barh(range(len(s)), s.values, color=colors, height=0.75)
    ax.set_yticks(range(len(s)))
    ax.set_yticklabels([_shorten(n) for n in s.index], fontsize=6)
    ax.set_xlabel("Importance / |coefficient|")
    if title:
        ax.set_title(title, fontsize=10)
    return _save(fig, path)


def _shorten(name: str, max_len: int = 42) -> str:
    return name if len(name) <= max_len else name[: max_len - 3] + "..."


# ---------------------------------------------------------------------------
# LASSO 路径与系数
# ---------------------------------------------------------------------------


def plot_lasso_cv(path_df: pd.DataFrame, path: str | Path, log_x: bool = True) -> List[str]:
    fig, ax = plt.subplots(figsize=(4.2, 3.4))
    x = path_df["alpha"]
    ax.errorbar(x, path_df["mse"], yerr=path_df["mse_se"], fmt="-", lw=1.2,
                ecolor="lightgrey", capsize=2, color="#c0392b")
    ax.set_xlabel("alpha")
    ax.set_ylabel("Mean squared error (10-fold CV)")
    if log_x:
        ax.set_xscale("log")
    return _save(fig, path)


def plot_lasso_coefficients(sel, path: str | Path) -> List[str]:
    """绘制保留特征的 LASSO 系数（对应稿件 coefficient plots）。"""
    s = pd.Series(sel.lasso_coef, index=sel.feature_names).sort_values()
    fig, ax = plt.subplots(figsize=(4.4, max(2.5, len(s) * 0.2)))
    ax.barh(range(len(s)), s.values, color=["#2e86c1" if v < 0 else "#c0392b" for v in s.values], height=0.7)
    ax.set_yticks(range(len(s)))
    ax.set_yticklabels([_shorten(n, 30) for n in s.index], fontsize=6)
    ax.axvline(0, color="black", lw=0.6)
    ax.set_xlabel("LASSO coefficient")
    return _save(fig, path)


# ---------------------------------------------------------------------------
# 生境可视化
# ---------------------------------------------------------------------------


def plot_habitat_map(
    image: np.ndarray,
    level1: np.ndarray,
    level2: np.ndarray,
    path: str | Path,
    case_id: int | str = "",
) -> List[str]:
    """三面板：原图 + ROI 一级生境覆盖 + 嵌套二级子生境。"""
    fig, axes = plt.subplots(1, 3, figsize=(9.6, 3.4))
    axes[0].imshow(image, cmap="gray")
    axes[0].set_title("Ultrasound image", fontsize=9)

    axes[1].imshow(image, cmap="gray")
    masked = np.ma.masked_where(level1 <= 0, level1)
    axes[1].imshow(masked, cmap="tab10", alpha=0.45, interpolation="nearest")
    axes[1].set_title("First-level habitats", fontsize=9)

    axes[2].imshow(image, cmap="gray")
    masked2 = np.ma.masked_where(level2 <= 0, level2)
    axes[2].imshow(masked2, cmap="Set1", alpha=0.5, interpolation="nearest")
    axes[2].set_title("Nested sub-habitats", fontsize=9)

    for ax in axes:
        ax.axis("off")
    if case_id:
        fig.suptitle(f"Case {case_id}", fontsize=10)
    return _save(fig, path)


# ---------------------------------------------------------------------------
# 列线图
# ---------------------------------------------------------------------------


def plot_nomogram(
    comps: List[dict],
    path: str | Path,
    total_range: Tuple[float, float] = (-6, 6),
) -> List[str]:
    """简化版列线图：上方各变量刻度，下方总分-概率轴。"""
    n = len(comps)
    fig, axes = plt.subplots(n + 2, 1, figsize=(5.2, 0.55 * (n + 2) + 0.8))
    for i, comp in enumerate(comps):
        ax = axes[i]
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_yticks([])
        ax.set_xticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.text(0.0, 0.5, _shorten(comp["feature"], 18), fontsize=8, va="center")
        ax.plot([0.35, 0.98], [0.5, 0.5], color="black", lw=0.8)
        ax.text(0.35, 0.15, f"{comp['raw_min']:.2f}", fontsize=7, ha="left")
        ax.text(0.98, 0.15, f"{comp['raw_max']:.2f}", fontsize=7, ha="right")
        ax.text(0.66, 0.78, f"beta = {comp['beta']:.2f}", fontsize=6.5, ha="center", color="grey")

    # 总分轴
    ax = axes[n]
    ax.set_xlim(*total_range)
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.plot(list(total_range), [0.5, 0.5], color="black", lw=1.0)
    for t in np.arange(np.ceil(total_range[0]), total_range[1] + 0.01, 2):
        ax.plot([t, t], [0.45, 0.55], color="black", lw=0.8)
        ax.text(t, 0.25, f"{t:g}", fontsize=7, ha="center")
    ax.text(total_range[0], 0.8, "Total points", fontsize=8, ha="left")

    # 概率轴
    ax = axes[n + 1]
    ax.set_xlim(*total_range)
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.plot(list(total_range), [0.5, 0.5], color="black", lw=1.0)
    for t in np.arange(np.ceil(total_range[0]), total_range[1] + 0.01, 2):
        p = 1 / (1 + np.exp(-t))
        ax.text(t, 0.2, f"{p:.2f}", fontsize=7, ha="center")
    ax.text(total_range[0], 0.8, "Predicted risk", fontsize=8, ha="left")
    return _save(fig, path)


# ---------------------------------------------------------------------------
# 模型比较条形图（DeLong / NRI / IDI）
# ---------------------------------------------------------------------------


def plot_comparison_bars(
    table: pd.DataFrame,
    path: str | Path,
    title: str = "",
    metric_col: str = "value",
    p_col: str = "p_value",
) -> List[str]:
    """table 需含 reference/cohort/metric/value/p_value 列。"""
    cohorts = list(dict.fromkeys(table["cohort"]))
    metrics_list = list(dict.fromkeys(table["metric"]))
    fig, axes = plt.subplots(1, len(metrics_list), figsize=(3.4 * len(metrics_list), 3.4), squeeze=False)
    for j, met in enumerate(metrics_list):
        ax = axes[0][j]
        sub = table[table["metric"] == met]
        labels, vals, colors = [], [], []
        for _, row in sub.iterrows():
            labels.append(f"{row['reference']}\n{row['cohort']}")
            vals.append(row[metric_col])
            colors.append("#c0392b" if row[p_col] < 0.05 else "lightgrey")
        x = np.arange(len(labels))
        ax.bar(x, vals, color=colors, width=0.7)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, fontsize=5, rotation=45, ha="right")
        ax.axhline(0, color="black", lw=0.6)
        ax.set_title(met, fontsize=9)
        if title and j == 0:
            ax.set_ylabel(title, fontsize=8)
    return _save(fig, path)


# ---------------------------------------------------------------------------
# 分组箱线图（免疫标志物，Fig.6a）
# ---------------------------------------------------------------------------


def plot_group_boxplot(
    df: pd.DataFrame,
    group_col: str,
    value_cols: Sequence[str],
    path: str | Path,
    p_values: Optional[Dict[str, float]] = None,
) -> List[str]:
    n = len(value_cols)
    fig, axes = plt.subplots(1, n, figsize=(2.6 * n, 3.2), squeeze=False)
    for j, col in enumerate(value_cols):
        ax = axes[0][j]
        groups = [df.loc[df[group_col] == g, col].dropna().values for g in sorted(df[group_col].unique())]
        ax.boxplot(groups, widths=0.55, showfliers=False,
                   medianprops={"color": "#c0392b", "lw": 1.0})
        for k, g in enumerate(groups):
            x = np.random.RandomState(42).normal(k + 1, 0.05, len(g))
            ax.scatter(x, g, s=8, color="#2e86c1", alpha=0.7, zorder=3)
        ax.set_xticks(range(1, len(groups) + 1))
        ax.set_xticklabels([str(g) for g in sorted(df[group_col].unique())])
        ax.set_title(col, fontsize=9)
        if p_values and col in p_values:
            ax.text(0.5, 0.95, f"P = {p_values[col]:.3f}", transform=ax.transAxes,
                    ha="center", fontsize=7)
    return _save(fig, path)


def plot_sample_distribution(
    y_true: np.ndarray,
    y_score: np.ndarray,
    path: str | Path,
    title: str = "",
) -> List[str]:
    fig, ax = plt.subplots(figsize=(3.6, 3.0))
    y_true = np.asarray(y_true).astype(int)
    for label, color, name in [(0, "#2e86c1", "Non-recurrence"), (1, "#c0392b", "Recurrence")]:
        ax.hist(np.asarray(y_score)[y_true == label], bins=20, alpha=0.55, color=color, label=name)
    ax.set_xlabel("Predicted probability")
    ax.set_ylabel("Count")
    if title:
        ax.set_title(title, fontsize=9)
    ax.legend(fontsize=7)
    return _save(fig, path)
