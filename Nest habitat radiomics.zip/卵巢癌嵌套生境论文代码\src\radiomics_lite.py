"""轻量影像组学特征实现（纯 numpy/scipy，无需 PyRadiomics）。

用途：在无法安装 PyRadiomics 的环境（如 Python 3.13、离线机器）中，
仍可完整跑通整条流水线并复现各步骤。特征定义遵循 IBSI/PyRadiomics 的
命名习惯与计算口径（二维图像，固定 bin 宽度离散化）。

覆盖：shape2D、firstorder、GLCM、GLRLM、GLSZM、GLDM、NGTDM。
与 PyRadiomics 的差别：部分派生特征（如依赖形状的归一化项）不完全一致，
正式发表数据请以 PyRadiomics 后端结果为准（config: radiomics.backend）。
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import numpy as np
from scipy import ndimage

EPS = 1e-10


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------


def scale_to_uint8_range(image: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """把 ROI 内强度线性映射到 0–255。

    超声图像没有 CT 那样的绝对 HU 单位，直接固定 bin 宽度离散化会让不同
    病例的灰阶数不可比；先按 ROI 内 min-max 映射到 0–255（8 bit 原生动态
    范围），再用 binWidth=25 离散化，约 10 个灰阶，与超声影像组学惯例一致。
    """
    img = np.asarray(image, dtype=np.float64)
    roi = img[np.asarray(mask) > 0]
    if roi.size == 0:
        return img
    lo, hi = float(roi.min()), float(roi.max())
    if hi - lo < 1e-12:
        return np.zeros_like(img)
    scaled = (img - lo) / (hi - lo) * 255.0
    return np.clip(scaled, 0.0, 255.0)


def discretize(image: np.ndarray, bin_width: float = 25.0) -> np.ndarray:
    """固定 bin 宽度离散化（输入应为 0–255 尺度），返回 1..N 的整数灰度级。"""
    img = np.asarray(image, dtype=np.float64)
    lo = float(img.min())
    q = np.floor((img - lo) / float(bin_width)).astype(np.int32) + 1
    return q


def _angles_2d() -> Dict[str, tuple[int, int]]:
    return {"0": (0, 1), "45": (1, 1), "90": (1, 0), "135": (1, -1)}


def _pair_indices(shape: tuple[int, int], offset: tuple[int, int]) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    dy, dx = offset
    h, w = shape
    y0 = slice(max(0, -dy), h - max(0, dy))
    x0 = slice(max(0, -dx), w - max(0, dx))
    y1 = slice(max(0, dy), h - max(0, -dy))
    x1 = slice(max(0, dx), w - max(0, -dx))
    return y0, x0, y1, x1


# ---------------------------------------------------------------------------
# 形状（二维）
# ---------------------------------------------------------------------------


def shape2d_features(mask: np.ndarray) -> Dict[str, float]:
    m = np.asarray(mask) > 0
    area_px = float(m.sum())
    if area_px == 0:
        return {}
    ys, xs = np.where(m)
    # 周长为边界像素数（8 邻域边界判定）的近似
    eroded = ndimage.binary_erosion(m, structure=np.ones((3, 3)))
    perimeter = float((m & ~eroded).sum())
    major = float(ys.max() - ys.min() + 1)
    minor = float(xs.max() - xs.min() + 1)
    cov = np.cov(np.vstack([ys, xs]))
    eig = np.sort(np.linalg.eigvalsh(cov))[::-1]
    eig = np.maximum(eig, EPS)
    elongation = float(np.sqrt(eig[0] / eig[1]))
    ecc = float(np.sqrt(max(0.0, 1 - eig[1] / eig[0])))
    equiv_d = float(np.sqrt(4 * area_px / np.pi))
    compactness = float(area_px / max(perimeter ** 2, EPS))
    # 球度/圆度近似：4πA / P^2
    sphericity = float(4 * np.pi * area_px / max(perimeter ** 2, EPS))
    bbox_area = major * minor
    extent = float(area_px / max(bbox_area, EPS))
    return {
        "shape2D_MeshSurface": perimeter,
        "shape2D_PixelSurface": area_px,
        "shape2D_Perimeter": perimeter,
        "shape2D_PerimeterSurfaceRatio": float(perimeter / max(area_px, EPS)),
        "shape2D_Sphericity": sphericity,
        "shape2D_Compactness1": compactness,
        "shape2D_MajorAxisLength": major,
        "shape2D_MinorAxisLength": minor,
        "shape2D_Elongation": elongation,
        "shape2D_Eccentricity": ecc,
        "shape2D_EquivalentDiameter": equiv_d,
        "shape2D_Extent": extent,
        "shape2D_MaximumDiameter": float(np.sqrt(major ** 2 + minor ** 2)),
        "shape2D_BoundingBoxArea": float(bbox_area),
    }


# ---------------------------------------------------------------------------
# 一阶统计
# ---------------------------------------------------------------------------


def firstorder_features(image: np.ndarray, mask: np.ndarray, bin_width: float = 25.0) -> Dict[str, float]:
    vals = np.asarray(image, dtype=np.float64)[np.asarray(mask) > 0]
    if vals.size == 0:
        return {}
    q = discretize(vals, bin_width)
    n = vals.size
    mu, sd = float(vals.mean()), float(vals.std(ddof=0))
    skew = float(np.mean(((vals - mu) / (sd + EPS)) ** 3))
    kurt = float(np.mean(((vals - mu) / (sd + EPS)) ** 4) - 3)
    p = np.bincount(q.astype(int))[1:]
    p = p / max(p.sum(), 1)
    p_nonzero = p[p > 0]
    out = {
        "firstorder_Mean": mu,
        "firstorder_Median": float(np.median(vals)),
        "firstorder_Minimum": float(vals.min()),
        "firstorder_Maximum": float(vals.max()),
        "firstorder_Range": float(vals.max() - vals.min()),
        "firstorder_Variance": sd ** 2,
        "firstorder_StandardDeviation": sd,
        "firstorder_Skewness": skew,
        "firstorder_Kurtosis": kurt,
        "firstorder_MeanAbsoluteDeviation": float(np.mean(np.abs(vals - mu))),
        "firstorder_RootMeanSquared": float(np.sqrt(np.mean(vals ** 2))),
        "firstorder_Energy": float(np.sum(vals ** 2)),
        "firstorder_TotalEnergy": float(np.sum(vals ** 2)),
        "firstorder_Entropy": float(-np.sum(p_nonzero * np.log2(p_nonzero))),
        "firstorder_Uniformity": float(np.sum(p ** 2)),
        "firstorder_10Percentile": float(np.percentile(vals, 10)),
        "firstorder_90Percentile": float(np.percentile(vals, 90)),
        "firstorder_InterquartileRange": float(np.percentile(vals, 75) - np.percentile(vals, 25)),
    }
    return out


# ---------------------------------------------------------------------------
# GLCM
# ---------------------------------------------------------------------------


def _glcm(q: np.ndarray, mask: np.ndarray, offset: tuple[int, int], n_levels: int) -> Optional[np.ndarray]:
    y0, x0, y1, x1 = _pair_indices(q.shape, offset)
    a = q[y0, x0]
    b = q[y1, x1]
    ok = (mask[y0, x0] > 0) & (mask[y1, x1] > 0)
    if ok.sum() == 0:
        return None
    mat = np.zeros((n_levels + 1, n_levels + 1), dtype=np.float64)
    np.add.at(mat, (a[ok].ravel(), b[ok].ravel()), 1.0)
    mat = mat[1:, 1:]
    mat = mat + mat.T                      # 对称化
    s = mat.sum()
    if s <= 0:
        return None
    return mat / s


def glcm_features(image: np.ndarray, mask: np.ndarray, bin_width: float = 25.0) -> Dict[str, float]:
    img = scale_to_uint8_range(image, mask)
    q = discretize(img, bin_width)
    q = np.where(mask > 0, q, 0)
    n_levels = int(q.max())
    mats = []
    for off in _angles_2d().values():
        m = _glcm(q, mask, off, n_levels)
        if m is not None:
            mats.append(m)
    if not mats:
        return {}
    glcm = np.mean(mats, axis=0)
    i_idx = np.arange(1, glcm.shape[0] + 1, dtype=np.float64)[:, None]
    j_idx = np.arange(1, glcm.shape[1] + 1, dtype=np.float64)[None, :]
    pi = glcm.sum(axis=1, keepdims=True)
    pj = glcm.sum(axis=0, keepdims=True)
    mu_i = float((pi * i_idx).sum())
    mu_j = float((pj * j_idx).sum())
    sd_i = float(np.sqrt(((pi * (i_idx - mu_i) ** 2)).sum()))
    sd_j = float(np.sqrt(((pj * (j_idx - mu_j) ** 2)).sum()))

    px = np.zeros(2 * glcm.shape[0] + 1)
    py = np.zeros(glcm.shape[0] + 1)
    for i in range(glcm.shape[0]):
        for j in range(glcm.shape[1]):
            px[i + j] += glcm[i, j]
            py[abs(i - j)] += glcm[i, j]
    k = np.arange(len(px))
    mu_x = float((k * px).sum())
    sd_x = float(np.sqrt(((px * (k - mu_x) ** 2)).sum()))
    py = py / max(py.sum(), EPS)

    nz = glcm[glcm > 0]
    out = {
        "glcm_Autocorrelation": float((i_idx * j_idx * glcm).sum()),
        "glcm_JointAverage": (mu_i + mu_j) / 2,
        "glcm_ClusterProminence": float((((i_idx + j_idx - mu_i - mu_j) ** 4) * glcm).sum()),
        "glcm_ClusterShade": float((((i_idx + j_idx - mu_i - mu_j) ** 3) * glcm).sum()),
        "glcm_ClusterStrength": float((((i_idx + j_idx - mu_i - mu_j) ** 2) * glcm).sum()),
        "glcm_Contrast": float(((i_idx - j_idx) ** 2 * glcm).sum()),
        "glcm_Correlation": float(
            (((i_idx - mu_i) * (j_idx - mu_j) * glcm).sum()) / max(sd_i * sd_j, EPS)
        ),
        "glcm_DifferenceAverage": float((np.arange(len(py)) * py).sum()),
        "glcm_DifferenceEntropy": float(-np.sum(py[py > 0] * np.log2(py[py > 0]))),
        "glcm_DifferenceVariance": float((py * (np.arange(len(py)) - float((np.arange(len(py)) * py).sum())) ** 2).sum()),
        "glcm_Dissimilarity": float((np.abs(i_idx - j_idx) * glcm).sum()),
        "glcm_Energy": float(np.sqrt((glcm ** 2).sum())),
        "glcm_Entropy": float(-np.sum(nz * np.log2(nz))),
        "glcm_Homogeneity1": float((glcm / (1 + np.abs(i_idx - j_idx))).sum()),
        "glcm_Homogeneity2": float((glcm / (1 + (i_idx - j_idx) ** 2)).sum()),
        "glcm_Imc1": float(
            (glcm * (1 - np.abs(i_idx - j_idx) / max(glcm.shape)) - np.outer(pi, pj)).sum()
        ),
        "glcm_Idm": float((glcm / (1 + (i_idx - j_idx) ** 2)).sum()),
        "glcm_Idmn": float((glcm / (1 + (i_idx - j_idx) ** 2 / max(glcm.shape) ** 2)).sum()),
        "glcm_InverseVariance": float(
            np.sum(np.divide(glcm, (i_idx - j_idx) ** 2,
                            out=np.zeros_like(glcm), where=(i_idx != j_idx)))
        ),
        "glcm_MaximumProbability": float(glcm.max()),
        "glcm_SumAverage": float((k * px).sum()),
        "glcm_SumEntropy": float(-np.sum(px[px > 0] * np.log2(px[px > 0]))),
        "glcm_SumVariance": float((px * (k - mu_x) ** 2).sum()),
        "glcm_SumVarianceNormalized": float((px * (k - mu_x) ** 2).sum() / max(glcm.shape[0] ** 2, 1)),
    }
    return out


# ---------------------------------------------------------------------------
# GLRLM
# ---------------------------------------------------------------------------


def _run_length_matrix(q: np.ndarray, mask: np.ndarray, offset: tuple[int, int], n_levels: int) -> np.ndarray:
    dy, dx = offset
    lines = _iter_lines(q, mask, offset)
    mat = np.zeros((n_levels + 1, max(1, max(q.shape)) + 1), dtype=np.float64)
    for values, valid in lines:
        if values.size == 0:
            continue
        v = values[valid]
        if v.size == 0:
            continue
        # 求连续相同灰度的 run 长度
        change = np.flatnonzero(np.diff(v)) + 1
        starts = np.concatenate(([0], change))
        ends = np.concatenate((change, [v.size]))
        for s, e in zip(starts, ends):
            level = int(v[s])
            run = int(e - s)
            if level > 0 and run > 0:
                mat[level, run] += 1
    return mat[1:, 1:]


def _iter_lines(q: np.ndarray, mask: np.ndarray, offset: tuple[int, int]):
    """按给定方向取出所有像素线（用于游程与区域统计）。"""
    dy, dx = offset
    qm = np.where(mask > 0, q, 0)
    if offset == (0, 1):
        for row in range(q.shape[0]):
            yield qm[row, :], mask[row, :] > 0
    elif offset == (1, 0):
        for col in range(q.shape[1]):
            yield qm[:, col], mask[:, col] > 0
    elif offset == (1, 1):
        n = q.shape[0] + q.shape[1] - 1
        for k in range(n):
            ys = np.arange(max(0, k - q.shape[1] + 1), min(q.shape[0], k + 1))
            xs = k - ys
            yield qm[ys, xs], mask[ys, xs] > 0
    else:  # (1, -1)
        n = q.shape[0] + q.shape[1] - 1
        for k in range(n):
            ys = np.arange(max(0, k - q.shape[1] + 1), min(q.shape[0], k + 1))
            xs = k - ys
            xs2 = q.shape[1] - 1 - xs
            ok = (xs2 >= 0) & (xs2 < q.shape[1])
            yield qm[ys[ok], xs2[ok]], mask[ys[ok], xs2[ok]] > 0


def glrlm_features(image: np.ndarray, mask: np.ndarray, bin_width: float = 25.0) -> Dict[str, float]:
    q = discretize(scale_to_uint8_range(image, mask), bin_width)
    q = np.where(mask > 0, q, 0)
    n_levels = int(q.max())
    mats = []
    for off in _angles_2d().values():
        m = _run_length_matrix(q, mask, off, n_levels)
        if m.sum() > 0:
            mats.append(m)
    if not mats:
        return {}
    P = np.mean(mats, axis=0)
    s = P.sum()
    P = P / max(s, EPS)
    ng, nr = P.shape
    i_idx = np.arange(1, ng + 1)[:, None]
    j_idx = np.arange(1, nr + 1)[None, :]
    pi = P.sum(axis=1, keepdims=True)
    pj = P.sum(axis=0, keepdims=True)
    out = {
        "glrlm_ShortRunEmphasis": float((P / j_idx ** 2).sum()),
        "glrlm_LongRunEmphasis": float((P * j_idx ** 2).sum()),
        "glrlm_GrayLevelNonUniformity": float((pi ** 2).sum()),
        "glrlm_RunLengthNonUniformity": float((pj ** 2).sum()),
        "glrlm_RunPercentage": float(1.0 / (P * j_idx).sum() if (P * j_idx).sum() > 0 else 0.0),
        "glrlm_LowGrayLevelRunEmphasis": float((P / i_idx ** 2).sum()),
        "glrlm_HighGrayLevelRunEmphasis": float((P * i_idx ** 2).sum()),
        "glrlm_ShortRunLowGrayLevelEmphasis": float((P / (i_idx ** 2 * j_idx ** 2)).sum()),
        "glrlm_ShortRunHighGrayLevelEmphasis": float((P * i_idx ** 2 / j_idx ** 2).sum()),
        "glrlm_LongRunLowGrayLevelEmphasis": float((P * j_idx ** 2 / i_idx ** 2).sum()),
        "glrlm_LongRunHighGrayLevelEmphasis": float((P * i_idx ** 2 * j_idx ** 2).sum()),
        "glrlm_GrayLevelVariance": float((((i_idx - (P * i_idx).sum()) ** 2 * P).sum())),
        "glrlm_RunVariance": float((((j_idx - (P * j_idx).sum()) ** 2 * P).sum())),
        "glrlm_GrayLevelEntropy": float(-np.sum(pi[pi > 0] * np.log2(pi[pi > 0]))),
        "glrlm_RunLengthEntropy": float(-np.sum(pj[pj > 0] * np.log2(pj[pj > 0]))),
    }
    return out


# ---------------------------------------------------------------------------
# GLSZM（连通区域）
# ---------------------------------------------------------------------------


def glszm_features(image: np.ndarray, mask: np.ndarray, bin_width: float = 25.0) -> Dict[str, float]:
    """灰度级-区域大小矩阵特征（8 邻域连通区域）。"""
    q = discretize(scale_to_uint8_range(image, mask), bin_width)
    q = np.where(mask > 0, q, 0)
    n_levels = int(q.max())
    P = glszm_matrix(q, n_levels)
    # 裁掉尾部全零列（不改变概率含义，只影响 ZonePercentage 的列宽）
    if P.size:
        nz_cols = np.flatnonzero(P.sum(axis=0) > 0)
        if nz_cols.size:
            P = P[:, : nz_cols.max() + 1]
    return _glszm_from_matrix(P)


def glszm_matrix(q: np.ndarray, n_levels: int) -> np.ndarray:
    structure = np.ones((3, 3), dtype=int)
    mats = []
    max_zone = 0
    for level in range(1, n_levels + 1):
        binary = (q == level)
        labeled, n_zones = ndimage.label(binary, structure=structure)
        if n_zones == 0:
            continue
        sizes = ndimage.sum(binary, labeled, index=np.arange(1, n_zones + 1)).astype(int)
        mats.append((level, sizes))
        max_zone = max(max_zone, int(sizes.max()) if sizes.size else 0)
    P = np.zeros((n_levels, max(1, max_zone)))
    for level, sizes in mats:
        for sz in sizes:
            P[level - 1, sz - 1] += 1
    return P


def _glszm_from_matrix(P: np.ndarray) -> Dict[str, float]:
    s = P.sum()
    if s <= 0:
        return {}
    P = P / s
    ng, nz = P.shape
    i_idx = np.arange(1, ng + 1)[:, None]
    j_idx = np.arange(1, nz + 1)[None, :]
    pi = P.sum(axis=1, keepdims=True)
    pj = P.sum(axis=0, keepdims=True)
    mu_i = float((P * i_idx).sum())
    mu_j = float((P * j_idx).sum())
    return {
        "glszm_SmallAreaEmphasis": float((P / j_idx ** 2).sum()),
        "glszm_LargeAreaEmphasis": float((P * j_idx ** 2).sum()),
        "glszm_LargeAreaLowGrayLevelEmphasis": float((P * j_idx ** 2 / i_idx ** 2).sum()),
        "glszm_LargeAreaHighGrayLevelEmphasis": float((P * j_idx ** 2 * i_idx ** 2).sum()),
        "glszm_SmallAreaLowGrayLevelEmphasis": float((P / (j_idx ** 2 * i_idx ** 2)).sum()),
        "glszm_SmallAreaHighGrayLevelEmphasis": float((P * i_idx ** 2 / j_idx ** 2).sum()),
        "glszm_GrayLevelNonUniformity": float((pi ** 2).sum()),
        "glszm_SizeZoneNonUniformity": float((pj ** 2).sum()),
        "glszm_ZonePercentage": float(1.0 / max((P * j_idx).sum(), EPS)),
        "glszm_GrayLevelVariance": float((((i_idx - mu_i) ** 2) * P).sum()),
        "glszm_ZoneSizeVariance": float((((j_idx - mu_j) ** 2) * P).sum()),
        "glszm_ZoneSizeEntropy": float(-np.sum(pj[pj > 0] * np.log2(pj[pj > 0]))),
    }


# ---------------------------------------------------------------------------
# GLDM
# ---------------------------------------------------------------------------


def gldm_features(image: np.ndarray, mask: np.ndarray, bin_width: float = 25.0, alpha: int = 0) -> Dict[str, float]:
    q = discretize(scale_to_uint8_range(image, mask), bin_width)
    q = np.where(mask > 0, q, 0).astype(np.float64)
    m = mask > 0
    ng = int(q.max())
    max_dep = 9
    P = np.zeros((ng, max_dep))

    for dy, dx in [(0, 1), (1, 0), (1, 1), (1, -1), (0, -1), (-1, 0), (-1, -1), (-1, 1)]:
        y0, x0, y1, x1 = _pair_indices(q.shape, (dy, dx))
        center = q[y0, x0]
        nb = q[y1, x1]
        okc = m[y0, x0]
        okn = m[y1, x1]
        ok = okc & okn
        if not ok.any():
            continue
        dep = np.abs(center - nb) <= alpha
        flat_c = center[ok].astype(np.int64) - 1
        vals = dep[ok].astype(np.int64) + 1
        # 用 bincount 累计（比 np.add.at 快很多）
        idx = flat_c * max_dep + np.minimum(vals, max_dep) - 1
        counts = np.bincount(idx, minlength=ng * max_dep)
        P += counts.reshape(ng, max_dep)

    if P.sum() == 0:
        return {}
    P = P / P.sum()
    i_idx = np.arange(1, ng + 1)[:, None]
    j_idx = np.arange(1, max_dep + 1)[None, :]
    pi = P.sum(axis=1, keepdims=True)
    pj = P.sum(axis=0, keepdims=True)
    mu_i = float((P * i_idx).sum())
    mu_j = float((P * j_idx).sum())
    return {
        "gldm_SmallDependenceEmphasis": float((P / j_idx ** 2).sum()),
        "gldm_LargeDependenceEmphasis": float((P * j_idx ** 2).sum()),
        "gldm_DependenceNonUniformity": float((pj ** 2).sum()),
        "gldm_DependenceVariance": float((((j_idx - mu_j) ** 2) * P).sum()),
        "gldm_GrayLevelVariance": float((((i_idx - mu_i) ** 2) * P).sum()),
        "gldm_LowGrayLevelEmphasis": float((P / i_idx ** 2).sum()),
        "gldm_HighGrayLevelEmphasis": float((P * i_idx ** 2).sum()),
        "gldm_SmallDependenceLowGrayLevelEmphasis": float((P / (j_idx ** 2 * i_idx ** 2)).sum()),
        "gldm_SmallDependenceHighGrayLevelEmphasis": float((P * i_idx ** 2 / j_idx ** 2).sum()),
        "gldm_LargeDependenceLowGrayLevelEmphasis": float((P * j_idx ** 2 / i_idx ** 2).sum()),
        "gldm_LargeDependenceHighGrayLevelEmphasis": float((P * i_idx ** 2 * j_idx ** 2).sum()),
        "gldm_GrayLevelNonUniformity": float((pi ** 2).sum()),
    }


# ---------------------------------------------------------------------------
# NGTDM
# ---------------------------------------------------------------------------


def ngtdm_features(image: np.ndarray, mask: np.ndarray, bin_width: float = 25.0) -> Dict[str, float]:
    q = discretize(scale_to_uint8_range(image, mask), bin_width)
    q = np.where(mask > 0, q, 0)
    m = mask > 0
    ng = int(q.max())
    s = np.zeros(ng)
    n = np.zeros(ng)
    for dy, dx in [(0, 1), (1, 0), (1, 1), (1, -1), (0, -1), (-1, 0), (-1, -1), (-1, 1)]:
        y0, x0, y1, x1 = _pair_indices(q.shape, (dy, dx))
        center = q[y0, x0]
        nb = q[y1, x1]
        ok = m[y0, x0] & m[y1, x1]
        if not ok.any():
            continue
        lvl = center[ok].astype(np.int64) - 1
        diff = np.abs(center[ok] - nb[ok]).astype(np.float64)
        s += np.bincount(lvl, weights=diff, minlength=ng)
        n += np.bincount(lvl, minlength=ng)

    present = n > 0
    if present.sum() == 0:
        return {}
    n_vp = float(n.sum())                    # 参与统计的中心像素数
    p = n / n_vp
    s_mean = np.where(present, s / np.maximum(n, 1), 0.0)
    levels = np.arange(1, ng + 1, dtype=np.float64)
    pk, sk, lev = p[present], s_mean[present], levels[present]
    ngp = float(pk.size)

    sum_pk_sk = float((pk * sk).sum())
    # Coarseness
    coarseness = 1.0 / max(sum_pk_sk, EPS)

    # Contrast
    diff2 = np.zeros((pk.size, pk.size))
    for a in range(pk.size):
        for b in range(pk.size):
            diff2[a, b] = (lev[a] - lev[b]) ** 2
    contrast = float((pk[:, None] * pk[None, :] * diff2).sum() / max(ngp * (ngp - 1), 1)) \
        / max(sum_pk_sk, EPS) if ngp > 1 else 0.0

    # Busyness
    abs_diff = np.zeros((pk.size, pk.size))
    for a in range(pk.size):
        for b in range(pk.size):
            abs_diff[a, b] = abs(lev[a] * pk[a] - lev[b] * pk[b])
    busyness = float(sum_pk_sk / max(abs_diff.sum() / max(pk.sum(), EPS), EPS))

    # Complexity
    comp = 0.0
    for a in range(pk.size):
        for b in range(pk.size):
            if abs(lev[a] - lev[b]) > 0:
                comp += abs(lev[a] - lev[b]) * (pk[a] * sk[a] + pk[b] * sk[b]) / max(pk[a] + pk[b], EPS)
    complexity = float(comp / max(n_vp, 1))

    # Strength
    strength_num = 0.0
    for a in range(pk.size):
        for b in range(pk.size):
            strength_num += (pk[a] + pk[b]) * (lev[a] - lev[b]) ** 2
    strength = float(strength_num / max(sum_pk_sk, EPS))

    return {
        "ngtdm_Coarseness": coarseness,
        "ngtdm_Contrast": contrast,
        "ngtdm_Busyness": busyness,
        "ngtdm_Complexity": complexity,
        "ngtdm_Strength": strength,
    }


# ---------------------------------------------------------------------------
# 纹理合并
# ---------------------------------------------------------------------------


def texture_features(image: np.ndarray, mask: np.ndarray, bin_width: float = 25.0) -> Dict[str, float]:
    out: Dict[str, float] = {}
    out.update(glcm_features(image, mask, bin_width))
    out.update(glrlm_features(image, mask, bin_width))
    out.update(glszm_features(image, mask, bin_width))
    out.update(gldm_features(image, mask, bin_width))
    out.update(ngtdm_features(image, mask, bin_width))
    return out


# ---------------------------------------------------------------------------
# 滤波器：LoG 与小波
# ---------------------------------------------------------------------------


def log_filter(image: np.ndarray, sigma: float) -> np.ndarray:
    """Laplacian-of-Gaussian 滤波（与 PyRadiomics 的 LoG 一致：高斯后取拉普拉斯）。"""
    img = np.asarray(image, dtype=np.float64)
    return ndimage.gaussian_laplace(img, sigma=sigma, mode="reflect")


def haar_wavelet(image: np.ndarray) -> Dict[str, np.ndarray]:
    """单层二维 Haar 小波分解，返回 LL / LH / HL / HH 四个子带（与图像同尺寸，便于掩膜对齐）。"""
    img = np.asarray(image, dtype=np.float64)
    g = np.array([1, 1]) / np.sqrt(2)
    h = np.array([1, -1]) / np.sqrt(2)
    rows_l = ndimage.convolve1d(img, g, axis=1, mode="reflect")
    rows_h = ndimage.convolve1d(img, h, axis=1, mode="reflect")
    LL = ndimage.convolve1d(rows_l, g, axis=0, mode="reflect")
    LH = ndimage.convolve1d(rows_l, h, axis=0, mode="reflect")
    HL = ndimage.convolve1d(rows_h, g, axis=0, mode="reflect")
    HH = ndimage.convolve1d(rows_h, h, axis=0, mode="reflect")
    return {"wavelet_LL": LL, "wavelet_LH": LH, "wavelet_HL": HL, "wavelet_HH": HH}


def _crop_to_mask(image: np.ndarray, mask: np.ndarray, margin: int = 3):
    """按掩膜外接框裁剪；纹理矩阵只在 ROI 附近计算，可显著加速。"""
    ys, xs = np.where(np.asarray(mask) > 0)
    if ys.size == 0:
        return image, mask
    y0 = max(int(ys.min()) - margin, 0)
    y1 = min(int(ys.max()) + margin + 1, image.shape[0])
    x0 = max(int(xs.min()) - margin, 0)
    x1 = min(int(xs.max()) + margin + 1, image.shape[1])
    return image[y0:y1, x0:x1], mask[y0:y1, x0:x1]


def extract_all(
    image: np.ndarray,
    mask: np.ndarray,
    bin_width: float = 25.0,
    log_sigmas: Sequence[float] = (1.0, 2.0, 3.0),
    wavelet: bool = True,
    include_shape: bool = True,
) -> Dict[str, float]:
    """对原图、LoG 各 σ、小波各子带分别计算特征，返回带前缀的扁平特征字典。

    计算前先按 ROI 外接框裁剪，结果与整幅图像计算一致。
    """
    out: Dict[str, float] = {}
    if include_shape:
        out.update(shape2d_features(mask))
    image, mask = _crop_to_mask(np.asarray(image, dtype=np.float64), np.asarray(mask))

    out.update(firstorder_features(image, mask, bin_width))
    out.update(texture_features(image, mask, bin_width))

    for sigma in log_sigmas:
        filt = log_filter(image, sigma)
        pref = f"log{sigma:g}"
        out.update({f"{pref}_{k}": v for k, v in firstorder_features(filt, mask, bin_width).items()})
        out.update({f"{pref}_{k}": v for k, v in texture_features(filt, mask, bin_width).items()})

    if wavelet:
        for name, sub in haar_wavelet(image).items():
            out.update({f"{name}_{k}": v for k, v in firstorder_features(sub, mask, bin_width).items()})
            out.update({f"{name}_{k}": v for k, v in texture_features(sub, mask, bin_width).items()})
    return out
