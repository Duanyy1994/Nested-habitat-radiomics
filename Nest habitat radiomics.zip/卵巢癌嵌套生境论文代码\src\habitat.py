"""嵌套生境（nested habitat）分割。

对应稿件 Methods「Nested habitat radiomics」：
    1. 5×5 像素二维滑窗在 ROI 掩膜内逐像素滑动，计算局部纹理特征，
       为每个像素生成多维局部特征向量；
    2. 第一轮 K-means 聚类，用 Calinski-Harabasz（CH）分数确定最优簇数，
       得到一级生境子区（first-level habitats）；
    3. 对面积最大的那个一级生境子区的像素子集，用同样的局部特征做第二轮
       K-means（同样用 CH 分数定簇数），得到嵌套的二级子生境
       （nested second-level sub-habitats）；
    4. 一级生境与嵌套二级子生境分别作为 ROI 提取影像组学特征。

局部特征（滑窗内）：
    mean        窗口均值
    std         窗口标准差（局部异质性强度）
    range       窗口极差
    entropy     窗口内 16 级灰度直方图的香农熵（局部纹理复杂度）
    skewness    窗口三阶标准化矩（局部灰度分布偏斜）
    contrast    窗口内相邻像素灰度绝对差的期望（GLCM 对比度的滑窗近似）
    homogeneity 1 / (1 + contrast)
    energy      窗口内归一化直方图的平方和（局部均匀性）
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy import ndimage

FEATURE_NAMES: Sequence[str] = (
    "mean",
    "std",
    "range",
    "entropy",
    "skewness",
    "contrast",
    "homogeneity",
    "energy",
)


# ---------------------------------------------------------------------------
# 局部（滑窗）特征
# ---------------------------------------------------------------------------


def _local_histogram_entropy(image: np.ndarray, size: int, bins: int = 16) -> np.ndarray:
    """滑窗灰度直方图熵：先把灰度量化到 bins 级，再用均值滤波累计各 bin 占比。"""
    img = image.astype(np.float32)
    lo, hi = float(img.min()), float(img.max())
    if hi - lo < 1e-6:
        return np.zeros_like(img)
    q = np.clip(((img - lo) / (hi - lo) * (bins - 1)).astype(np.int32), 0, bins - 1)
    p = np.zeros_like(img)
    for b in range(bins):
        onehot = (q == b).astype(np.float32)
        p_b = ndimage.uniform_filter(onehot, size=size, mode="nearest")
        p += np.where(p_b > 0, -p_b * np.log2(np.maximum(p_b, 1e-12)), 0.0)
    return p


def _local_contrast(image: np.ndarray, size: int) -> np.ndarray:
    """滑窗内相邻像素灰度绝对差的均值（GLCM 对比度的局部近似）。"""
    img = image.astype(np.float32)
    acc = np.zeros_like(img)
    n = 0
    for axis in (0, 1):
        d = np.abs(np.diff(img, axis=axis))
        pad = [(0, 0), (0, 0)]
        pad[axis] = (0, 1)
        d = np.pad(d, pad, mode="edge")
        acc += ndimage.uniform_filter(d, size=size, mode="nearest")
        n += 1
    return acc / max(n, 1)


def _local_skewness(image: np.ndarray, size: int) -> np.ndarray:
    img = image.astype(np.float32)
    m1 = ndimage.uniform_filter(img, size=size, mode="nearest")
    m2 = ndimage.uniform_filter(img ** 2, size=size, mode="nearest")
    m3 = ndimage.uniform_filter(img ** 3, size=size, mode="nearest")
    var = np.maximum(m2 - m1 ** 2, 0)
    sd = np.sqrt(var)
    third = m3 - 3 * m1 * m2 + 2 * m1 ** 3
    return np.where(sd > 1e-6, third / np.maximum(sd ** 3, 1e-6), 0.0)


def compute_local_features(
    image: np.ndarray,
    mask: np.ndarray,
    window_size: int = 5,
    features: Optional[Sequence[str]] = None,
) -> Tuple[np.ndarray, List[str]]:
    """返回 ROI 内每个像素的局部特征矩阵 (n_pixels, n_features) 及其像素坐标。

    返回:
        feats : (n_pixels, n_features) float32
        coords: (n_pixels, 2) int 数组，列为 (row, col)
        names : 特征名列表
    """
    names = list(features or FEATURE_NAMES)
    img = image.astype(np.float32)
    size = int(window_size)

    stack: Dict[str, np.ndarray] = {}
    if "mean" in names:
        stack["mean"] = ndimage.uniform_filter(img, size=size, mode="nearest")
    if "std" in names:
        m1 = ndimage.uniform_filter(img, size=size, mode="nearest")
        m2 = ndimage.uniform_filter(img ** 2, size=size, mode="nearest")
        stack["std"] = np.sqrt(np.maximum(m2 - m1 ** 2, 0))
    if "range" in names:
        stack["range"] = ndimage.maximum_filter(img, size=size, mode="nearest") - ndimage.minimum_filter(
            img, size=size, mode="nearest"
        )
    if "entropy" in names:
        stack["entropy"] = _local_histogram_entropy(img, size=size, bins=16)
    if "skewness" in names:
        stack["skewness"] = _local_skewness(img, size=size)
    if "contrast" in names or "homogeneity" in names:
        contrast = _local_contrast(img, size=size)
        if "contrast" in names:
            stack["contrast"] = contrast
        if "homogeneity" in names:
            stack["homogeneity"] = 1.0 / (1.0 + contrast)
    if "energy" in names:
        # 局部直方图平方和
        lo, hi = float(img.min()), float(img.max())
        bins = 16
        if hi - lo < 1e-6:
            stack["energy"] = np.zeros_like(img)
        else:
            q = np.clip(((img - lo) / (hi - lo) * (bins - 1)).astype(np.int32), 0, bins - 1)
            e = np.zeros_like(img)
            for b in range(bins):
                p_b = ndimage.uniform_filter((q == b).astype(np.float32), size=size, mode="nearest")
                e += p_b ** 2
            stack["energy"] = e

    coords = np.argwhere(mask > 0)
    if coords.size == 0:
        raise ValueError("ROI 掩膜为空，无法计算局部特征")
    feats = np.stack([stack[name][coords[:, 0], coords[:, 1]] for name in names], axis=1)
    return feats.astype(np.float32), coords


# ---------------------------------------------------------------------------
# 聚类与生境生成
# ---------------------------------------------------------------------------


def _best_kmeans(
    feats: np.ndarray,
    k_range: Sequence[int],
    n_init: int = 10,
    max_iter: int = 300,
    random_state: int = 42,
) -> Tuple[object, int, Dict[int, float]]:
    """在 k_range 内用 CH 分数选择最优簇数的 K-means。"""
    from sklearn.cluster import KMeans
    from sklearn.metrics import calinski_harabasz_score, silhouette_score

    scores: Dict[int, float] = {}
    best_model, best_k, best_ch = None, None, -np.inf
    for k in k_range:
        k = int(k)
        if feats.shape[0] < k + 1:
            continue
        km = KMeans(n_clusters=k, n_init=n_init, max_iter=max_iter, random_state=random_state)
        labels = km.fit_predict(feats)
        if len(np.unique(labels)) < 2:
            continue
        ch = calinski_harabasz_score(feats, labels)
        scores[k] = float(ch)
        if ch > best_ch:
            best_model, best_k, best_ch = km, k, ch
    if best_model is None:
        raise ValueError("K-means 聚类失败：ROI 像素数不足")
    # 轮廓系数仅用于结果表记录（不参与选择）
    try:
        scores_extra = {"silhouette": float(silhouette_score(feats, best_model.labels_))}
    except Exception:
        scores_extra = {}
    return best_model, int(best_k), {**scores, **scores_extra}


def nested_habitat_segmentation(
    image: np.ndarray,
    mask: np.ndarray,
    cfg: dict,
    random_state: int = 42,
    sample_pixels: int = 0,
) -> Dict[str, object]:
    """两轮 K-means 嵌套生境分割。

    返回字典:
        level1_labels : (H, W) int，一级生境标签（1..K，背景 0）
        level2_labels : (H, W) int，嵌套二级子生境标签（100+s），0 表示非嵌套区域
        ch_scores     : {'round1': {...}, 'round2': {...}}
        k1, k2        : 两轮最优簇数
        area_ratio    : {label: 像素占比}
        local_features: 局部特征名
    """
    h = cfg.get("habitat", {})
    size = int(h.get("window_size", 5))
    feats_names = h.get("local_features", list(FEATURE_NAMES))
    k1_range = h.get("kmeans_round1_k_range", [2, 3, 4, 5, 6])
    k2_range = h.get("kmeans_round2_k_range", [2, 3, 4])
    n_init = int(h.get("kmeans_n_init", 10))
    max_iter = int(h.get("kmeans_max_iter", 300))
    nested_from = h.get("nested_from", "largest_area")
    min_pixels = int(h.get("min_pixels", 30))
    sample_pixels = int(sample_pixels or h.get("sample_pixels", 0) or 0)

    feats, coords = compute_local_features(image, mask, window_size=size, features=feats_names)

    # 聚类前标准化（局部特征量纲差异大）
    mu, sd = feats.mean(axis=0), feats.std(axis=0)
    sd[sd < 1e-6] = 1.0
    z = (feats - mu) / sd

    # ---------------- 第一轮 ----------------
    # 像素数很多时先用随机子集拟合 K-means（子集上限 sample_pixels），
    # 再对全部 ROI 像素 predict，这样聚类质心稳定且耗时可控。
    if sample_pixels and z.shape[0] > sample_pixels:
        rs1 = np.random.RandomState(random_state)
        fit_idx = np.sort(rs1.choice(z.shape[0], sample_pixels, replace=False))
    else:
        fit_idx = np.arange(z.shape[0])
    km1, k1, ch1 = None, 1, {}
    try:
        km1, k1, ch1 = _best_kmeans(z[fit_idx], k1_range, n_init=n_init,
                                    max_iter=max_iter, random_state=random_state)
        lab1_pix = km1.predict(z)
    except ValueError:
        # ROI 像素过少无法聚类：退化为单个一级生境（全 ROI）
        lab1_pix = np.zeros(z.shape[0], dtype=int)
    level1 = np.zeros(mask.shape, dtype=np.int32)
    level1[coords[:, 0], coords[:, 1]] = lab1_pix + 1

    areas = {int(l + 1): int((lab1_pix == l).sum()) for l in np.unique(lab1_pix)}
    total = float(sum(areas.values()))
    area_ratio = {k: v / total for k, v in areas.items()}

    # ---------------- 第二轮：嵌套 ----------------
    if nested_from == "largest_area":
        seed_label = max(areas, key=areas.get)
    else:
        seed_label = int(nested_from)
    seed_mask = lab1_pix == (seed_label - 1)

    level2 = np.zeros(mask.shape, dtype=np.int32)
    k2, ch2 = None, {}
    if int(seed_mask.sum()) >= max(min_pixels * 2, 10):
        z2 = z[seed_mask]
        sub_coords = coords[seed_mask]
        idx = np.arange(z2.shape[0])
        if sample_pixels and z2.shape[0] > sample_pixels:
            rs = np.random.RandomState(random_state)
            idx = np.sort(rs.choice(z2.shape[0], sample_pixels, replace=False))
        km2, k2, ch2 = _best_kmeans(
            z2[idx], k2_range, n_init=n_init, max_iter=max_iter, random_state=random_state
        )
        sub_lab = km2.predict(z2)
        level2[sub_coords[:, 0], sub_coords[:, 1]] = sub_lab + 100

    return {
        "level1_labels": level1,
        "level2_labels": level2,
        "ch_scores": {"round1": ch1, "round2": ch2},
        "k1": k1,
        "k2": k2,
        "area_ratio": area_ratio,
        "seed_label": seed_label,
        "local_features": list(feats_names),
    }


# ---------------------------------------------------------------------------
# 由生境标签图生成各子区掩膜（供逐区提取影像组学特征）
# ---------------------------------------------------------------------------


def habitat_masks(seg: Dict[str, object], min_pixels: int = 30) -> Dict[str, np.ndarray]:
    """返回 {生境名: 二值掩膜}。

    一级: H1_1 ... H1_K；嵌套二级: H2_1 ... H2_m（仅最大一级生境内）
    """
    out: Dict[str, np.ndarray] = {}
    l1 = np.asarray(seg["level1_labels"])
    for lab in np.unique(l1):
        if lab <= 0:
            continue
        m = (l1 == lab).astype(np.uint8)
        if m.sum() >= min_pixels:
            out[f"H1_{int(lab)}"] = m
    l2 = np.asarray(seg["level2_labels"])
    for lab in np.unique(l2):
        if lab <= 0:
            continue
        m = (l2 == lab).astype(np.uint8)
        if m.sum() >= min_pixels:
            out[f"H2_{int(lab) - 100}"] = m
    return out


def habitat_summary(seg: Dict[str, object], case_id: int, modality: str) -> Dict[str, object]:
    """单例单模态的生境分割摘要，写入结果表。"""
    row: Dict[str, object] = {
        "case_id": case_id,
        "modality": modality,
        "k1": seg["k1"],
        "k2": seg["k2"],
        "seed_habitat": seg["seed_label"],
        "ch_round1": seg["ch_scores"]["round1"].get(seg["k1"], np.nan),
        "ch_round2": seg["ch_scores"]["round2"].get(seg["k2"], np.nan) if seg["k2"] else np.nan,
    }
    for lab, ratio in sorted(seg["area_ratio"].items()):
        row[f"H1_{lab}_ratio"] = ratio
    return row
